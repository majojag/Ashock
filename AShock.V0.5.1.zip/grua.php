<!DOCTYPE html>
<html>
	<head>
		
		<?php
			@session_start();
			if (!isset($_SESSION['id_perfil'])) {
				header('Location: registrar.php');
			}else{
				$id_perfil=$_SESSION['id_perfil'];
				if($id_perfil==1){ header('Location: dashboard.php'); }
				if($id_perfil==2){ header('Location: dashboard.php'); }
				if($id_perfil==3){ header('Location: usuarios.php'); }
				if($id_perfil==4){ header('Location: taller.php'); }
			}
			require("db/conectar.php");
			require("db/consulta_usuario.php");
			require("ext/metas.php");
			require("ext/styles.php");
			require("ext/scripts.php");
		
		/* ------- CSS --------*/
			echo 
				$favicon.
				$bootstrap_css.
				$font_awesome.
				$estructure.
				$style_css.
				$responsive_css
			;
		/* ------- CSS --------*/
		/* -------- JS --------*/
			echo 
				$jquery.
				$bootstrap_js.
				$main.
				$Key
			;
		/* -------- JS --------*/
		?>
		
	</head>
	<body>
		<div id="wrapper">
			<div class="overlay"></div>
			<!-- Sidebar -->
			<nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">				
				<ul class="nav sidebar-nav">
					<li class="sidebar-brand" style="background: #000 url(<?php if($login==1) { echo $foto_frontal; } ?>) no-repeat; background-size: cover;">
						<img src="<?php if($login==1){echo $foto_perfil;} ?>" class="img-circle" width="67" alt="">
						<p><?php if($login==1){echo $correo;} ?></p>
					</li>
					<li>
						<a id="micuenta" href="#Micuenta">Mi cuenta</a>
					</li>
					<li>
						<a id="historia" href="#">Historial</a>
					</li>
					<li>
						<a class="ayuda" href="#">Ayuda</a>
					</li>
					<li>
						<a class="cerrar" href="#">Cerrar sesión</a>
					</li>
					<hr width="100%"><br>
					<center style="clear:both;">
						<img src="img/logo.png" width="45%" alt="">
					</center>
					<h4 align="center">Ashock</h4>
				</ul>
			</nav>
			<!-- /#sidebar-wrapper -->
			<!-- Page Content -->
			<div id="page-content-wrapper">
				
				<div id="home">
					<header>
						<div class="header-top clearfix">
							<a class="l-left toggle-menu" href="#">
								<button type="button" class="hamburger is-closed" data-toggle="offcanvas">
									<span class="hamb-top"></span>
									<span class="hamb-middle"></span>
									<span class="hamb-bottom"></span>
								</button>
							</a>
						</div>
					</header>
					<div id="fullpage">
						<div id="map"></div>
						<script>
							function initMap() {
						        var map = new google.maps.Map(document.getElementById('map'), {
						          center: {lat: 4.677424, lng: -74.048205},
						          zoom: 17
						        });
						        var DivMap = document.getElementById('map');
						        if (navigator.geolocation) {
									navigator.geolocation.getCurrentPosition(function(position) {
										lat=position.coords.latitude;
										lon=position.coords.longitude;
										var coordenadas = new google.maps.LatLng( lat, lon );
										var ConfigMap = {
											zoom: 17,
											center: coordenadas
										};
										var GMap = new google.maps.Map( DivMap, ConfigMap );
										var Car = {
											position: coordenadas,
											map: GMap,
											title: "eres tu",
											fillOpacity: .9,
											animation: google.maps.Animation.DROP
										};
										var IconCar = new google.maps.Marker( Car);
										IconCar.setIcon( "img/icons/grua.png" );
										var longitud=lon;
										var latitud=lat;
										var registrar = setInterval(registrarcadaminuto, 1000);
										function registrarcadaminuto() {
											Car = {
												position: coordenadas,
												map: GMap,
												title: "eres tu"
											};
											IconCar = new google.maps.Marker( Car);
											IconCar.setIcon( "img/icons/grua.png" );
											$.ajax({
												url  : 'db/ubicaciones.php?longitud='+longitud+'&latitud='+latitud,
												beforeSend : function(){
												},
												success : function(response){
													if(response!=1){
														alert(response);
													}
											   }
											 });
										}
									});
						        }else{
						        	alert("sin gps");
						        }
							}
						</script>
		    			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVHQ-vbUvaGZQUx5MweCwlE8oMwVieIAw&callback=initMap" async defer></script>
					</div>
					<footer class="desktop">
						<h6 align="center">
							<img id="grua_u" src="img/icon3.png" alt="grua">
						</h6>
					</footer>
				</div>
				
			</div>		
		</div>
		<script type="text/javascript" src="https://ashock.app:3000/socket.io/socket.io.js"></script>
	</body>
</html>
