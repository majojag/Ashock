				<form id="register-taller" method="post" enctype="multipart/form-data">
					<div id="taller1" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Taller 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente1"></i>
								</h2>
							</div>
						</header>
						<div class="container"><br><br>
							<div class="form-group">
								<label class="control-label">Fotografia taller*</label>
								<label for="imagen_taller" style="cursor: pointer; width: 100% !important;">
									<img id="foto_taller" src="img/vehiculos/foto.png" width="100%" alt="">
								</label>
								<input id="imagen_taller" type="file" name="imagen_taller" style="display: none; cursor: pointer !important;">
								<input type="number" class="form-control" name="id_perfil" value="4" style="display: none">
							</div>
							<div class="form-group">
								<label class="control-label" for="nit">Nit*</label>
								<input type="number" name="nit" placeholder="00000000" class="form-control" id="nit" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="nombres">Empresa*</label>
								<input type="text" name="empresa" placeholder="Taller_Empresa" class="form-control" id="empresa" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="direccion">Dirección*</label>
								<input type="email" name="dir_empresa" placeholder="Cra 0 #00-00" class="form-control" id="dir_empresa" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="correo">Correo(Usuario)*</label>
								<input type="text" name="correo_empresa" autocomplete="off" value="" class="form-control" id="correo_empresa" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="contrasena">Contraseña*</label>
								<input type="password" autocomplete="off" name="contra_empresa" class="form-control" id="contra_empresa" required>
							</div>
							<button id="siguiente_taller1" class="btn btn-warning btn-big siguiente1" type="button">Siguiente</button>
						</div><br><br>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar_taller1" class="l-left regresar1" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="taller2" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Taller 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente2"></i>
								</h2>
							</div>
						</header>
						<div class="container"><br><br>
							<div class="form-group">
								<label class="control-label" for="telefono">Numero de contacto*</label>
								<input type="number" class="form-control" name="telefono_empresa" id="telefono_empresa" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="dias">Días de atención*</label>
								<input type="text" class="form-control" placeholder="lunes a viernes" name="dias_atencion" id="dias" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="dias">Días de atención*</label>
							</div>
							<div class="form-group col-sm-12 col-md-6 col-lg-6">
								<label class="control-label" for="hora_inicio">Desde </label> 
								<select name="hora_inicio" class="time" id="hora_inicio">
									<option value="01">01 AM</option>
									<option value="02">02 AM</option>
									<option value="03">03 AM</option>
									<option value="04">04 AM</option>
									<option value="05">05 AM</option>
									<option value="06">06 AM</option>
									<option value="07">07 AM</option>
									<option value="08">08 AM</option>
									<option value="09">09 AM</option>
									<option value="10">10 AM</option>
									<option value="11">11 AM</option>
									<option value="12">12 PM</option>
									<option value="13">01 PM</option>
									<option value="14">02 PM</option>
									<option value="15">03 PM</option>
									<option value="16">04 PM</option>
									<option value="17">05 PM</option>
									<option value="18">06 PM</option>
									<option value="19">07 PM</option>
									<option value="20">08 PM</option>
									<option value="21">09 PM</option>
									<option value="22">10 PM</option>
									<option value="23">11 PM</option>
									<option value="24">12 AM</option>
								</select>
								<select name="minuto_inicio" class="time" id="minuto_inicio">
									<option value="00">00 Minutos</option>
									<option value="01">01 Minuto</option>
									<option value="02">02 Minutos</option>
									<option value="03">03 Minutos</option>
									<option value="04">04 Minutos</option>
									<option value="05">05 Minutos</option>
									<option value="06">06 Minutos</option>
									<option value="07">07 Minutos</option>
									<option value="08">08 Minutos</option>
									<option value="09">09 Minutos</option>
									<option value="10">10 Minutos</option>
									<option value="11">11 Minutos</option>
									<option value="12">12 Minutos</option>
									<option value="13">13 Minutos</option>
									<option value="14">14 Minutos</option>
									<option value="15">15 Minutos</option>
									<option value="16">16 Minutos</option>
									<option value="17">17 Minutos</option>
									<option value="18">18 Minutos</option>
									<option value="19">19 Minutos</option>
									<option value="20">20 Minutos</option>
									<option value="21">21 Minutos</option>
									<option value="22">22 Minutos</option>
									<option value="23">23 Minutos</option>
									<option value="24">24 Minutos</option>
									<option value="25">25 Minutos</option>
									<option value="26">26 Minutos</option>
									<option value="27">27 Minutos</option>
									<option value="28">28 Minutos</option>
									<option value="29">29 Minutos</option>
									<option value="30">30 Minutos</option>
									<option value="31">31 Minutos</option>
									<option value="32">32 Minutos</option>
									<option value="33">33 Minutos</option>
									<option value="34">34 Minutos</option>
									<option value="35">35 Minutos</option>
									<option value="36">36 Minutos</option>
									<option value="37">37 Minutos</option>
									<option value="38">38 Minutos</option>
									<option value="39">39 Minutos</option>
									<option value="40">40 Minutos</option>
									<option value="41">41 Minutos</option>
									<option value="42">42 Minutos</option>
									<option value="43">43 Minutos</option>
									<option value="44">44 Minutos</option>
									<option value="45">45 Minutos</option>
									<option value="46">46 Minutos</option>
									<option value="47">47 Minutos</option>
									<option value="48">48 Minutos</option>
									<option value="49">49 Minutos</option>
									<option value="50">50 Minutos</option>
									<option value="51">51 Minutos</option>
									<option value="52">52 Minutos</option>
									<option value="53">53 Minutos</option>
									<option value="54">54 Minutos</option>
									<option value="55">55 Minutos</option>
									<option value="56">56 Minutos</option>
									<option value="57">57 Minutos</option>
									<option value="58">58 Minutos</option>
									<option value="59">59 Minutos</option>
								</select>
								<input type="number" placeholder="Segundo" name="segundo_inicio" class="time hidden" value="00">
							</div>
							<div class="form-group col-sm-12 col-md-6 col-lg-6">
								<label class="control-label" for="horas_atencion">Hasta </label>
								<select name="hora_fin" class="time" id="hora_fin">
									<option value="01">01 AM</option>
									<option value="02">02 AM</option>
									<option value="03">03 AM</option>
									<option value="04">04 AM</option>
									<option value="05">05 AM</option>
									<option value="06">06 AM</option>
									<option value="07">07 AM</option>
									<option value="08">08 AM</option>
									<option value="09">09 AM</option>
									<option value="10">10 AM</option>
									<option value="11">11 AM</option>
									<option value="12">12 PM</option>
									<option value="13">01 PM</option>
									<option value="14">02 PM</option>
									<option value="15">03 PM</option>
									<option value="16">04 PM</option>
									<option value="17">05 PM</option>
									<option value="18">06 PM</option>
									<option value="19">07 PM</option>
									<option value="20">08 PM</option>
									<option value="21">09 PM</option>
									<option value="22">10 PM</option>
									<option value="23">11 PM</option>
									<option value="24">12 AM</option>
								</select>
								<select name="minuto_fin" class="time" id="minuto_fin">
									<option value="00">00 Minutos</option>
									<option value="01">01 Minuto</option>
									<option value="02">02 Minutos</option>
									<option value="03">03 Minutos</option>
									<option value="04">04 Minutos</option>
									<option value="05">05 Minutos</option>
									<option value="06">06 Minutos</option>
									<option value="07">07 Minutos</option>
									<option value="08">08 Minutos</option>
									<option value="09">09 Minutos</option>
									<option value="10">10 Minutos</option>
									<option value="11">11 Minutos</option>
									<option value="12">12 Minutos</option>
									<option value="13">13 Minutos</option>
									<option value="14">14 Minutos</option>
									<option value="15">15 Minutos</option>
									<option value="16">16 Minutos</option>
									<option value="17">17 Minutos</option>
									<option value="18">18 Minutos</option>
									<option value="19">19 Minutos</option>
									<option value="20">20 Minutos</option>
									<option value="21">21 Minutos</option>
									<option value="22">22 Minutos</option>
									<option value="23">23 Minutos</option>
									<option value="24">24 Minutos</option>
									<option value="25">25 Minutos</option>
									<option value="26">26 Minutos</option>
									<option value="27">27 Minutos</option>
									<option value="28">28 Minutos</option>
									<option value="29">29 Minutos</option>
									<option value="30">30 Minutos</option>
									<option value="31">31 Minutos</option>
									<option value="32">32 Minutos</option>
									<option value="33">33 Minutos</option>
									<option value="34">34 Minutos</option>
									<option value="35">35 Minutos</option>
									<option value="36">36 Minutos</option>
									<option value="37">37 Minutos</option>
									<option value="38">38 Minutos</option>
									<option value="39">39 Minutos</option>
									<option value="40">40 Minutos</option>
									<option value="41">41 Minutos</option>
									<option value="42">42 Minutos</option>
									<option value="43">43 Minutos</option>
									<option value="44">44 Minutos</option>
									<option value="45">45 Minutos</option>
									<option value="46">46 Minutos</option>
									<option value="47">47 Minutos</option>
									<option value="48">48 Minutos</option>
									<option value="49">49 Minutos</option>
									<option value="50">50 Minutos</option>
									<option value="51">51 Minutos</option>
									<option value="52">52 Minutos</option>
									<option value="53">53 Minutos</option>
									<option value="54">54 Minutos</option>
									<option value="55">55 Minutos</option>
									<option value="56">56 Minutos</option>
									<option value="57">57 Minutos</option>
									<option value="58">58 Minutos</option>
									<option value="59">59 Minutos</option>
								</select>
								<input type="number" placeholder="Segundo" name="segundo_fin" class="time hidden" value="00">
							</div>
							<button id="siguiente_taller2" class="btn btn-warning btn-big siguiente2" type="button">Siguiente</button>
						</div><br><br>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar_taller2" class="l-left regresar2" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="taller3" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px" class="fa fa-check l-right guardar_taller"></i>
								</h2>
							</div>
						</header>
						<div class="container">
							<center><img src="img/logo.png" width="45%" alt=""></center>
							<br><h1 align="center">Assistane Shock</h1><br>
							<p align="center">
								<input type="checkbox" id="t2" class="c2" required>
								<label for="t2">
									<span></span> Acepto las 
									<a href="ext/docs/politicas.pdf" target="_blank">
										Política de privacidad, Términos y condiciones
									</a>
								</label>
							</p>
							<div id="error_taller" class="error"></div>
							<button id="guardar_taller" class="btn btn-warning btn-big guardar_taller" type="button">Aceptar</button><br><br>
						</div><br><br>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar_taller3" class="l-left regresar3" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>
				</form>