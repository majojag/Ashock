				<ul class="menu-micuena">
					<li id="personal">
						<h3>Registro Personal</h3>
					</li>
					<li id="vehiculo">
						<h3>Registro del Vehículo</h3>
					</li>
					<li id="fotos">
						<h3>Fotografías  del Vehículo</h3>
					</li>
				</ul><br><br>
					<div id="micuenta1" class="hidden">
						<header>
							<div class="header-top clearfix">
								<p style="color: #FFFFFF; font-size: 26px; line-height: 59px">
									<i class="fa fa-arrow-left return-chat" style="color: #FFFFFF; font-size: 26px; line-height: 59px"></i>
									Mi Cuenta
								</p>
							</div>
						</header>
						<div class="container">
							<div class="form-group">
								<p align="center">
									<label for="imagen" style="cursor: pointer">
										<img id="foto5" src="<?php echo $foto_perfil; ?>" width="92" alt="">
									</label>
									<input id="imagen5" type="file" name="foto_perfil" style="display: none; cursor: pointer !important;">
								</p>
							</div>
							<div class="form-group">
								<label class="control-label" for="cedula">Cédula *</label>
								<input type="number" class="form-control" id="cedula" name="cedula" value="<?php echo $cedula; ?>" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="placa">Placa del Vehículo *</label>
								<input type="text" class="form-control" id="placa" name="placa" value="<?php echo $placa; ?>" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="nombres">Nombres *</label>
								<input type="text" class="form-control" id="nombres" name="nombres" value="<?php echo $nombres; ?>" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="apellidos">Apellidos *</label>
								<input type="text" class="form-control" id="apellidos" name="apellidos" value="<?php echo $apellidos; ?>" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="correo">Correo Electrónico *</label>
								<input type="text" class="form-control" id="correo2" name="correo2" value="<?php echo $correo; ?>" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="contrasena">Contraseña *</label>
								<input type="password" class="form-control" id="contrasena" name="contrasena" value="<?php echo $contrasena; ?>" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="telefono">Numero de contacto *</label>
								<input type="number" class="form-control" id="telefono" name="telefono" value="<?php echo $telefono; ?>" required>
							</div>
							<button type="button" class="btn btn-warning editar_cuenta">Guardar</button>
						</div>
					</div>

					<div id="micuenta2" class="hidden">
						<header>
							<div class="header-top clearfix">
								<p style="color: #FFFFFF; font-size: 26px; line-height: 59px">
									<i class="fa fa-arrow-left return-chat" style="color: #FFFFFF; font-size: 26px; line-height: 59px"></i>
									Mi Cuenta
								</p>
							</div>
						</header>
						<div class="container">
							<br><br><br>
								<div class="form-group">
									<label class="control-label" for="">Tipo de Vehículo*</label>
									<select id="tipo_vehiculo" name="tipo_vehiculo" class="form-control">
										<option value="<?php echo $id_tipo_car; ?>"><?php echo $tipo_car; ?></option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label" for="">Fabricante del Vehículo*</label>
									<select id="fabricante" name="fabricante" class="form-control">
										<option value="<?php echo $id_fabricante; ?>"><?php echo $fabricante; ?></option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label" for="">Modelo del Vehículo *</label>
									<select id="modelos" name="modelos" class="form-control">
										<option value="<?php echo $id_modelo; ?>"><?php echo $modelo; ?></option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label" for="">Año de Fabricación  del vehículo *</label>
									<select id="anos" name="anos" class="form-control">
										<option value="<?php echo $id_ano; ?>"><?php echo $ano; ?></option>
									</select>
								</div>
							<button type="button" class="btn btn-warning editar_cuenta">Guardar</button>
						</div>
					</div>

					<div id="micuenta3" class="hidden">
						<header>
							<div class="header-top clearfix">
								<p style="color: #FFFFFF; font-size: 26px; line-height: 59px">
									<i class="fa fa-arrow-left return-chat" style="color: #FFFFFF; font-size: 26px; line-height: 59px"></i>
									Mi Cuenta
								</p>
							</div>
						</header>
						<div class="container"><br>
							<div class="form-group">
								<label class="control-label" for="">Fotografía vista frontal del vehículo *</label><br/>
								<label for="imagen7" style="cursor: pointer">
									<img id="foto7" src="<?php echo $foto_frontal; ?>" alt="">
								</label>
								<input id="imagen7" type="file" name="foto_frontal" style="display: none; cursor: pointer !important;">
							</div>
							<div class="form-group">
								<label class="control-label" for="">Fotografía perfil lateral derecho *</label><br/>
								<label for="imagen8" style="cursor: pointer">
										<img id="foto8" src="<?php echo $foto_derecha; ?>" alt="">
									</label>
								<input id="imagen8" type="file" name="foto_derecha" style="display: none; cursor: pointer !important;">
							</div>
							<div class="form-group">
								<label class="control-label" for="">Fotografía vista trasera del vehículo *</label><br/>
								<label for="imagen9" style="cursor: pointer">
									<img id="foto9" src="<?php echo $foto_trasera; ?>" alt="">
								</label>
								<input id="imagen9" type="file" name="foto_izquierda" style="display: none; cursor: pointer !important;">
							</div>
							<div class="form-group">
								<label class="control-label" for="">Fotografía perfil lateral izquierdo *</label><br/>
								<label for="imagen10" style="cursor: pointer">
									<img id="foto10" src="<?php echo $foto_izquierda; ?>" alt="">
								</label>
								<input id="imagen10" type="file" name="foto_trasera" style="display: none; cursor: pointer !important;">
							</div>
							<button type="button" class="btn btn-warning editar_cuenta">Guardar</button>
						</div>
					</div>