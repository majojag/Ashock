-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-12-2018 a las 04:53:06
-- Versión del servidor: 10.1.36-MariaDB
-- Versión de PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ashock`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `anos`
--

CREATE TABLE `anos` (
  `id_ano` int(11) NOT NULL,
  `ano` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `anos`
--

INSERT INTO `anos` (`id_ano`, `ano`) VALUES
(1, 2001),
(2, 2002),
(3, 2003),
(4, 2004),
(5, 2005),
(6, 2006),
(7, 2007),
(8, 2008),
(9, 2009),
(10, 2010),
(11, 2011),
(12, 2012),
(13, 2013),
(14, 2014),
(15, 2015),
(16, 2016),
(17, 2017),
(18, 2018),
(19, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carros`
--

CREATE TABLE `carros` (
  `id` int(11) NOT NULL,
  `placa` varchar(7) COLLATE utf8_spanish_ci NOT NULL,
  `id_tipo_car` int(11) NOT NULL,
  `id_fabricante` int(11) NOT NULL,
  `id_modelo` int(11) NOT NULL,
  `id_ano` int(11) NOT NULL,
  `foto_frontal` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `foto_derecha` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `foto_izquierda` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `foto_trasera` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `tipo_grua` varchar(50) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `citas_taller`
--

CREATE TABLE `citas_taller` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Block'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `citas_taller`
--

INSERT INTO `citas_taller` (`id`, `title`, `date`, `created`, `modified`, `status`) VALUES
(1, 'taller 1', '2018-12-18', '2018-12-17 00:00:00', '2018-12-18 10:29:20', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fabricantes`
--

CREATE TABLE `fabricantes` (
  `id_fabricante` int(11) NOT NULL,
  `fabricante` varchar(100) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fabricantes`
--

INSERT INTO `fabricantes` (`id_fabricante`, `fabricante`) VALUES
(1, 'AUDI'),
(2, 'BMW'),
(3, 'CHEVROLET'),
(4, 'FERRARI'),
(5, 'HYUNDAI'),
(6, 'LAMBORGHINI'),
(7, 'ninguno');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `geolocalizacion`
--

CREATE TABLE `geolocalizacion` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `longitud` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `latitud` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` date NOT NULL DEFAULT '0000-00-00',
  `hora` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `geolocalizacion`
--

INSERT INTO `geolocalizacion` (`id`, `id_user`, `longitud`, `latitud`, `fecha`, `hora`) VALUES
(1, 3, '-74.0768336', '4.5783762999999995', '2018-12-17', '22:23:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelos`
--

CREATE TABLE `modelos` (
  `id_modelo` int(11) NOT NULL,
  `modelo` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id_fabricante` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `modelos`
--

INSERT INTO `modelos` (`id_modelo`, `modelo`, `id_fabricante`) VALUES
(1, 'A8', 1),
(2, 'SQ7', 1),
(3, 'TTS', 1),
(4, 'SERIE 7', 2),
(5, 'X5', 2),
(6, 'Z4', 2),
(7, 'CRUZE', 3),
(8, 'SPARK', 3),
(9, 'CAMARO', 3),
(10, '488', 4),
(11, 'GTC4', 4),
(12, 'CALIFORNIA', 4),
(13, 'F12', 5),
(14, 'VELOSTER', 5),
(15, 'GENESIS', 5),
(16, 'KONA', 5),
(17, 'AVENTADOR', 6),
(18, 'HURACÁN', 6),
(19, 'MURCÍELAGO', 6),
(20, '0', 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil`
--

CREATE TABLE `perfil` (
  `id` int(11) NOT NULL,
  `perfil` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `perfil`
--

INSERT INTO `perfil` (`id`, `perfil`) VALUES
(1, 'SuperAdministrador'),
(2, 'Adminstrador'),
(3, 'Usuario'),
(4, 'Taller'),
(5, 'Grúa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes`
--

CREATE TABLE `reportes` (
  `id` int(11) NOT NULL,
  `reporte` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `talleres`
--

CREATE TABLE `talleres` (
  `id` int(11) NOT NULL,
  `id_perfil` int(11) NOT NULL,
  `nit` bigint(15) NOT NULL,
  `empresa` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(110) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `contrasena` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` bigint(10) NOT NULL,
  `foto_taller` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `hora_abierto` time NOT NULL,
  `hora_cerrado` time NOT NULL,
  `dias_atencion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE `tipos` (
  `id_tipo_car` int(11) NOT NULL,
  `tipo_car` varchar(100) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`id_tipo_car`, `tipo_car`) VALUES
(1, 'Bus'),
(2, 'Camion'),
(3, 'Camioneta'),
(4, 'Grua'),
(5, 'Furgoneta'),
(8, 'Particular'),
(9, 'Taxi'),
(10, 'Tractor'),
(12, 'Otro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `id_car` int(11) NOT NULL,
  `id_perfil` int(11) NOT NULL,
  `cedula` int(11) NOT NULL,
  `telefono` decimal(10,0) NOT NULL,
  `nombres` text COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` text COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `contrasena` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `foto_perfil` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `id_car`, `id_perfil`, `cedula`, `telefono`, `nombres`, `apellidos`, `correo`, `contrasena`, `foto_perfil`, `estado`, `fecha`, `hora`) VALUES
(1, 1, 1, 1010199194, '3165398393', 'Ashock', '', 'assistanceshock@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', './img/perfil/users/1543987030_26926.png', 'activo', '2018-12-05', '00:17:10'),
(2, 2, 2, 1091285435, '3208731079', 'Miguel', 'Castillo', 'webmaster@mcdeveloper.co', '81dc9bdb52d04dc20036dbd8313ed055', './img/perfil/users/1543988164_10706.jpg', 'activo', '2018-12-05', '00:36:04'),
(3, 3, 5, 775444322, '3165398393', 'MIGUEL', 'CASTILLO', 'xxsumperxx@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', './img/perfil/gruas/1543992245_80397.jpg', 'activo', '2018-12-05', '01:44:05'),
(4, 4, 3, 1642249, '3165398393', 'Mauro', 'Carzo', 'mau@hotmail.com', '81dc9bdb52d04dc20036dbd8313ed055', './img/perfil/users/1544578448_26054.jpg', 'activo', '2018-12-11', '20:34:08'),
(5, 5, 2, 1075658629, '1234', 'José Alejandro', 'García', 'majojag@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', './img/perfil/users/sin_foto.png', 'activo', '2018-12-12', '00:10:29');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `anos`
--
ALTER TABLE `anos`
  ADD PRIMARY KEY (`id_ano`);

--
-- Indices de la tabla `carros`
--
ALTER TABLE `carros`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `citas_taller`
--
ALTER TABLE `citas_taller`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `fabricantes`
--
ALTER TABLE `fabricantes`
  ADD PRIMARY KEY (`id_fabricante`);

--
-- Indices de la tabla `geolocalizacion`
--
ALTER TABLE `geolocalizacion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `modelos`
--
ALTER TABLE `modelos`
  ADD PRIMARY KEY (`id_modelo`),
  ADD KEY `id_fabricante` (`id_fabricante`);

--
-- Indices de la tabla `perfil`
--
ALTER TABLE `perfil`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `talleres`
--
ALTER TABLE `talleres`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipos`
--
ALTER TABLE `tipos`
  ADD PRIMARY KEY (`id_tipo_car`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `anos`
--
ALTER TABLE `anos`
  MODIFY `id_ano` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `carros`
--
ALTER TABLE `carros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `citas_taller`
--
ALTER TABLE `citas_taller`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `fabricantes`
--
ALTER TABLE `fabricantes`
  MODIFY `id_fabricante` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `geolocalizacion`
--
ALTER TABLE `geolocalizacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `modelos`
--
ALTER TABLE `modelos`
  MODIFY `id_modelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `perfil`
--
ALTER TABLE `perfil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `reportes`
--
ALTER TABLE `reportes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `talleres`
--
ALTER TABLE `talleres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipos`
--
ALTER TABLE `tipos`
  MODIFY `id_tipo_car` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `modelos`
--
ALTER TABLE `modelos`
  ADD CONSTRAINT `modelos_ibfk_1` FOREIGN KEY (`id_fabricante`) REFERENCES `fabricantes` (`id_fabricante`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
