$(document).ready(function() {
	"use strict";
	
		window.onbeforeunload = function (e) {
		  /*var e = e || window.event;
		  // For IE and Firefox
		  if (e) {
			e.returnValue = 'Tu mensaje para el usuario';
		  }
		  // For Safari
		  return 'Tu mensaje para el usuario';*/
		};
		
		$.getJSON('db/contar_usuarios.php',function(contar_usuarios){
			$.each(contar_usuarios, function(numero_usuarios,numero_gruas,numero_talleres){
				$("#numero_usuarios").html(contar_usuarios.numero_usuarios);
				$("#numero_gruas").html(contar_usuarios.numero_gruas);
				$("#numero_talleres").html(contar_usuarios.numero_talleres);
			});
		});
				
		
	var inputsearch = $(".search-user").val();
	var nickuser = 0;
	$(".search-user").keypress(function() {
		inputsearch = $(".search-user").val();
		$.ajax({
			url  : 'db/buscar_usuario.php?cedula='+$(".search-user").val(),
			beforeSend: function(){
				$(".getusers").html('');
				$(".getusers").show();
				$(".getusers").html('<div class="alert alert-warning" role="alert"> Buscando ... </div>');
			},
			success : function(response){
				$(".getusers").html('');
				$(".getusers").show();
				$(".getusers").html('<div class="" role="alert"> '+response+' </div>');
				$(".respuser").click(function() {
					nickuser = $(this).data("cedula");
					$(".getusers").hide();
					$("#editar").show();
					$.getJSON('db/form_usuario.php?cedula='+nickuser,function(form_usuario){
						$.each(form_usuario, function(nombres,apellidos,cedula,telefono,correo,placa){
							$("#nombres_form1").val(form_usuario.nombres);
							$("#apellidos_form1").val(form_usuario.apellidos);
							$("#cedula_form1").val(form_usuario.cedula);
							$("#correo_form1").val(form_usuario.correo);
							$("#placa_form1").val(form_usuario.placa);
						});
					});
					$.getJSON('db/fabricante_vehiculo.php',function(fabricante_vehiculo){
						$.each(fabricante_vehiculo, function(id,fabricante){
							$("#marca_form1").append('<option value="'+id+'">'+fabricante+'</option>');
						});
					});
					$.getJSON('db/modelo_vehiculo.php?id_fabricante=1',function(modelos){
						$.each(modelos, function(id,modelo){
							$("#modelo_form1").append('<option value="'+id+'">'+modelo+'</option>');
						});
					});
					$.getJSON('db/ano_vehiculo.php',function(ano_vehiculo){
						$.each(ano_vehiculo, function(id,ano){
							$("#ano_form1").append('<option value="'+id+'">'+ano+'</option>');
						});
					});
				});
			}
		});
	});
	$(".btn-search-users").click(function() {
		$.ajax({
			url  : 'db/buscar_usuario.php?cedula='+inputsearch,
			beforeSend: function(){
				$(".getusers").html('');
				$(".getusers").show();
				$(".getusers").html('<div class="alert alert-warning" role="alert"> Cargando ... </div>');
			},
			success : function(response){
				$(".getusers").html('');
				$(".getusers").show();
				$(".getusers").html('<div class="" role="alert"> '+response+' </div>');
		   }
		});
		inputsearch = $(".search-user").val();
	});
		
		$.ajax({
			url  : 'db/chat_usuario.php',
			beforeSend: function(){
				$("#user_chat").html('');
				$("#user_chat").html('<div class="alert alert-warning" role="alert"> Buscando ... </div>');
			},
			success : function(response){
				$("#user_chat").html('');
				$("#user_chat").html(response);
			
				$(".respuser").click(function(){
					var cedula = $(this).data("cedula");
					$.getJSON('db/form_usuario.php?cedula='+cedula ,function(form_usuario){
						$.each(form_usuario, function(nombres,apellidos,cedula,telefono,foto_perfil,correo,placa){
							$("#nickname1").html(form_usuario.correo);
							$("#catimg").attr("src", form_usuario.foto_perfil);
								
							
						});
						
					});	
							
				});	
							
							
							
	var socket = io.connect('https://ashock.app:3000');
	var sms = document.getElementById("audio");
	
	var id = 1;
	var perfil = 1;
	var admin = "assistanceshock@gmail.com";
	var username = $("#nickname1").html();
	var foto = "./img/icon_assistance.png";
	var message = document.getElementById("message");
							
							
	function chat(){
		socket.emit('chatsend:message', {
			id: id,
			perfil: perfil,
			username: admin,
			message: message.value,
			foto: foto
		});
		$("#message").val("");
	}
socket.on('chatget:message', function (data) {
		if(data.perfil === 1){
				var send_message =
					'<p id="sms" align="right">'+
						'<div class="send_message" style="">'+data.message+'</div>'+
						'<img src="'+foto+'" width="45" style="position: relative; top: -67px; float: left;" alt="">'+
					'</p>';
				$("#bodychat").append(send_message).scrollTop($("#bodychat").prop('scrollHeight'));
		}else{
				sms.play();
				var get_message =
					'<p align="left">'+
						'<img src="'+data.foto+'" width="45" style="position: relative; top: 0px; float: right;" alt="">'+
						'<div class="get_message">'+data.message+'</div>'+
					'</p>';
				$("#bodychat").append(get_message).scrollTop($("#bodychat").prop('scrollHeight'));
		}
});

	$(".fa-send").click(function(){
		if ($("#message").val() != "") {
			chat();
		}	
	});
	$("#message").focus(function () {
		$("#message").keypress(function (e) {
			if (e.which === 13) {
				if ($("#message").val() != "") {
					chat();
				}
			}
		});
	});
	$("#message").keyup(function(){
		socket.emit('chat:writing', {
			username: admin,
			foto: foto
		});
	});
	socket.on('chat:writing', function(dato) {
		$("#estado").text(' esta escribiendo...');
		setTimeout(function(){
			$("#estado").text('');
		},2000);
	});
	
	
		   }
		});
		
		
		
		
		$.ajax({
			url  : 'db/editar_usuarios_a.php',
			beforeSend: function(){
				$("#editar_usuarios").html('');
				$("#editar_usuarios").html('<div class="alert alert-warning" role="alert"> Buscando ... </div>');
			},
			success : function(response){
				$("#editar_usuarios").html('');
				$("#editar_usuarios").html(response);
				
				
				$(".editar").click(function(){
					var cc = $(this).data("cedula");
					$.getJSON('db/form_usuario.php?cedula='+cc,function(form_usuario){
						$.each(form_usuario, function(nombres,apellidos,cedula,telefono,correo,placa){
							$("#nombres_form2").val(form_usuario.nombres);
							$("#apellidos_form2").val(form_usuario.apellidos);
							$("#cedula_form2").val(form_usuario.cedula);
							$("#telefono_form2").val(form_usuario.telefono);
							$("#correo_form2").val(form_usuario.correo);
							$("#placa_form2").val(form_usuario.placa);
						});
					});
					$.getJSON('db/fabricante_vehiculo.php',function(fabricante_vehiculo){
						$.each(fabricante_vehiculo, function(id,fabricante){
							$("#marca_form2").append('<option value="'+id+'">'+fabricante+'</option>');
						});
					});
					$.getJSON('db/modelo_vehiculo.php?id_fabricante=1',function(modelos){
						$.each(modelos, function(id,modelo){
							$("#modelo_form2").append('<option value="'+id+'">'+modelo+'</option>');
						});
					});
					$.getJSON('db/ano_vehiculo.php',function(ano_vehiculo){
						$.each(ano_vehiculo, function(id,ano){
							$("#ano_form2").append('<option value="'+id+'">'+ano+'</option>');
						});
					});
				
				});
				
				
			}
		});
		
		
		////////////////////////////////////////////////////////
		
		
	$("#search-roles").keypress(function() {
		inputsearch = $("#search-roles").val();
		$.ajax({
			url  : 'db/editar_roles.php?cedula='+inputsearch,
			beforeSend: function(){
				$("#editar_usuarios").html('');
				$("#editar_usuarios").show();
				$("#editar_usuarios").html('<div class="alert alert-warning" role="alert"> Buscando ... </div>');
			},
			success : function(response){
				$("#editar_usuarios").html('');
				$("#editar_usuarios").show();
				$("#editar_usuarios").html('<div class="" role="alert"> '+response+' </div>');
				$(".editar").click(function() {
					var cc = $(this).data("cedula");
					$.getJSON('db/form_usuario.php?cedula='+cc,function(form_roles){
						$.each(form_roles, function(nombres,apellidos,cedula,telefono,correo,placa){
							$("#nombres_form2").val(form_roles.nombres);
							$("#apellidos_form2").val(form_roles.apellidos);
							$("#cedula_form2").val(form_roles.cedula);
							$("#telefono_form2").val(form_roles.telefono);
							$("#correo_form2").val(form_roles.correo);
							$("#placa_form2").val(form_roles.placa);
						});
					});
					$.getJSON('db/fabricante_vehiculo.php',function(fabricante_vehiculo){
						$.each(fabricante_vehiculo, function(id,fabricante){
							$("#marca_form3").append('<option value="'+id+'">'+fabricante+'</option>');
						});
					});
					$.getJSON('db/modelo_vehiculo.php?id_fabricante=1',function(modelos){
						$.each(modelos, function(id,modelo){
							$("#modelo_form3").append('<option value="'+id+'">'+modelo+'</option>');
						});
					});
					$.getJSON('db/ano_vehiculo.php',function(ano_vehiculo){
						$.each(ano_vehiculo, function(id,ano){
							$("#ano_form3").append('<option value="'+id+'">'+ano+'</option>');
						});
					});
				
				});
		   }
		});
	});
		
		
		////////////////////////////////////////////////////////
		
		
	$("#search-gruas").keypress(function() {
		inputsearch = $("#search-gruas").val();
		$.ajax({
			url  : 'db/buscar_usuario.php?cedula='+inputsearch,
			beforeSend: function(){
				$(".getgruas").html('');
				$(".getgruas").show();
				$(".getgruas").html('<div class="alert alert-warning" role="alert"> Buscando ... </div>');
			},
			success : function(response){
				$(".getgruas").html('');
				$(".getgruas").show();
				$(".getgruas").html('<div class="" role="alert"> '+response+' </div>');
				$(".respuser").click(function() {
					$(".getgruas").hide();
					var cc = $(this).data("cedula");
					$.getJSON('db/form_usuario.php?cedula='+cc,function(form_gruas){
						$.each(form_gruas, function(nombres,apellidos,cedula,telefono,correo,placa){
							$("#nombres_form3").val(form_gruas.nombres);
							$("#apellidos_form3").val(form_gruas.apellidos);
							$("#cedula_form3").val(form_gruas.cedula);
							$("#telefono_form3").val(form_gruas.telefono);
							$("#correo_form3").val(form_gruas.correo);
							$("#placa_form3").val(form_gruas.placa);
						});
					});
					$.getJSON('db/fabricante_vehiculo.php',function(fabricante_vehiculo){
						$.each(fabricante_vehiculo, function(id,fabricante){
							$("#marca_form3").append('<option value="'+id+'">'+fabricante+'</option>');
						});
					});
					$.getJSON('db/modelo_vehiculo.php?id_fabricante=1',function(modelos){
						$.each(modelos, function(id,modelo){
							$("#modelo_form3").append('<option value="'+id+'">'+modelo+'</option>');
						});
					});
					$.getJSON('db/ano_vehiculo.php',function(ano_vehiculo){
						$.each(ano_vehiculo, function(id,ano){
							$("#ano_form3").append('<option value="'+id+'">'+ano+'</option>');
						});
					});
				
				});
		   }
		});
	});
		
		
});