<?php
require("conectar.php");
header('Content-Type: text/html; charset=utf-8');
html_entity_decode("UTF-8");
@session_start();
if (isset($_SESSION['id'])) {
	$id=$_SESSION['id'];
}else{
	$id=0;
}
	$query_users = $db_con->query("SELECT * FROM usuarios");
	while($users = $query_users->fetch(PDO::FETCH_ASSOC)) {
		$id_u = $users['id'];
		if ($id!=$id_u) {
			$id_car = $users['id_car'];
			$nombres = $users['nombres'];
			$cedula = $users['cedula'];
			$telefono = $users['telefono'];
			$apellidos = $users['apellidos'];
			$foto_perfil = $users['foto_perfil'];
			$contrasena = $users['contrasena'];
			$correo = $users['correo'];
			$estado = $users['estado'];
			echo '<p class="respuser" style="background: #EFEDED; padding: 10px 10px; border-radius: 5px; cursor: pointer" data-cedula="'.$cedula.'">'.
					'<img src="'.$foto_perfil.'" height="40" alt="">'.
					'<span class="nickname1"> '.$nombres.' </span>';
			if($estado=="activo"){
				echo '<span class="fa fa-circle" style="float: right; color: #00FF00; margin-top: 11px; font-size: 14px"></span>';
			}else{
				echo '<span class="fa fa-circle" style="float: right; color: #999999; margin-top: 11px"></span>';
			}			
				'</p>'
			;
		}
	}
?>