#Crear base de datos
CREATE DATABASE ashock;

#Entrar base de datos
USE ashock;

#Mostrar Tablas
SHOW TABLES;

#crear tablas

#TABLA1
CREATE TABLE tipos (
	id_tipo_car INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	tipo_car VARCHAR(100)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

#TABLA2
CREATE TABLE fabricantes (
	id_fabricante INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	fabricante VARCHAR(100)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

#TABLA3
CREATE TABLE modelos (
	id_modelo INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	modelo VARCHAR(100),
	id_fabricante INT NOT NULL,
    INDEX (id_fabricante),
    FOREIGN KEY (id_fabricante) REFERENCES fabricantes(id_fabricante)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

#TABLA4
CREATE TABLE anos (
	id_ano INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	ano INT NOT NULL
)
ENGINE=InnoDB
DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

#TABLA5
CREATE TABLE carros (
	id_car INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	id_aseguadora INT NOT NULL,
	placa VARCHAR(100),
	id_tipo_car INT NOT NULL,
	id_fabricante INT NOT NULL,
	id_modelo INT NOT NULL,
	id_ano INT NOT NULL,
	foto_frontal VARCHAR(1000),
	foto_derecha VARCHAR(1000),
	foto_izquierda VARCHAR(1000),
	foto_trasera VARCHAR(1000),
    INDEX (id_tipo_car),
    INDEX (id_fabricante),
    INDEX (id_ano),
    FOREIGN KEY (id_tipo_car) REFERENCES tipos(id_tipo_car),
	FOREIGN KEY (id_fabricante) REFERENCES fabricantes(id_fabricante),
	FOREIGN KEY (id_modelo) REFERENCES modelos(id_modelo),
	FOREIGN KEY (id_ano) REFERENCES anos(id_ano)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

#TABLA6
CREATE TABLE users (
	id_u INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	id_car INT NOT NULL,
	id_perfil INT NOT NULL,
	cedula INT NOT NULL,
	telefono BIGINT NOT NULL,
	nombres VARCHAR(100),
	apellidos VARCHAR(100),
	correo VARCHAR(100),
	contrasena VARCHAR(100),
	foto_perfil VARCHAR(1000),
	estado VARCHAR(100),
    INDEX (id_car,id_perfil),
	FOREIGN KEY (id_car) REFERENCES carros(id_car).
	FOREIGN KEY (id_perfil) REFERENCES perfil(id)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

#TABLA7
CREATE TABLE perfil (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	perfil VARCHAR(100),
	estado VARCHAR(100),
)
ENGINE=InnoDB
DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

#TABLA8
CREATE TABLE aseguradoras (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	aseguradora VARCHAR(100),
	estado VARCHAR(100)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

#TABLA9
CREATE TABLE servicios (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	tipo_servicio VARCHAR(100),	
	fecha_solicitud date default NULL,
	fecha_solucion date default NULL,
	fecha_pado date default NULL,
	pago BIGINT NULL
)
ENGINE=InnoDB
DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

#TABLA10
CREATE TABLE historial (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	id_accion INT NOT NULL,
	fecha date default NULL,
	estado VARCHAR(100)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;

#mostrar tablas
DESCRIBE users;
DESCRIBE carros;
DESCRIBE tipos;
DESCRIBE fabricantes;
DESCRIBE modelos;
DESCRIBE anos;

#Ingresar todo tipo de vehiculos #1
INSERT INTO tipos (tipo_car)
VALUES	('Bus'),
		('Camion'),
		('Camioneta'),
		('Grua'),
		('Mula'),
		('Particular'),
		('Taxi')
;

#Ingresar todas las marcas fabricantes #2
INSERT INTO fabricantes (fabricante)
VALUES	('AUDI'),
		('BMW'),
		('CHEVROLET'),
		('FERRARI'),
		('HYUNDAI'),
		('LAMBORGHINI')
;

#Ingresar año del vehiculo #3
INSERT INTO anos (ano)
VALUES	(1983),
		(1984),
		(1985),
		(1986),
		(1987),
		(1988),
		(1989),
		(1990),
		(1991),
		(1992),
		(1993),
		(1994),
		(1995),
		(1996),
		(1997),
		(1998),
		(1999),
		(2000),
		(2001),
		(2002),
		(2003),
		(2004),
		(2005),
		(2006),
		(2007),
		(2008),
		(2009),
		(2010),
		(2011),
		(2012),
		(2013),
		(2014),
		(2015),
		(2016),
		(2017),
		(2018)
;

#Ingresar todas los modelos #4
INSERT INTO modelos (modelo, id_fabricante)
VALUES	('A8',1),
		('SQ7',1),
		('TTS',1),
		('SERIE 7',2),
		('X5',2),
		('Z4',2),
		('CRUZE',3),
		('SPARK',3),
		('CAMARO',3),
		('488',4),
		('GTC4',4),
		('CALIFORNIA',4),
		('F12',5),
		('VELOSTER',5),
		('GENESIS',5),
		('KONA',5),
		('AVENTADOR',6),
		('HURACÁN',6),
		('MURCÍELAGO',6)
;

#Ingresar Usuario #7
#INSERT INTO users (`id_u`, `id_car`, `cedula`, `telefono`, `nombres`, `apellidos`, `correo`, `contrasena`, `foto_perfil`, `estado`) 
#VALUES (NULL, '1', '000000', '3100000000', 'Jose', 'Garcia', 'majojag@hotmail.com', '1234', './images/usuarios/sin_foto.jpg', 'inactivo');


#mostrar tablas
SELECT * FROM users;

#Consulta múltiples tablas
SELECT * FROM users, carros, tipos, fabricantes, modelos, anos, fotos  
WHERE users.id_u=1 
AND users.id_car=carros.id_car  
AND carros.id_tipo_car=tipos.id_tipo_car 
AND carros.id_fabricante=fabricantes.id_fabricante 
AND modelos.id_fabricante=fabricantes.id_fabricante 
AND carros.id_ano=anos.id_ano 
AND carros.id_foto=fotos.id_foto;

