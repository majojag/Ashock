<?php
	require("conectar.php");
	header('Content-Type: text/html; charset=utf-8');
	html_entity_decode("UTF-8");

$cedula = $_GET["cedula"];
	$tipo_usuarios = $db_con->query("SELECT * FROM usuarios WHERE cedula like '$cedula%'");
	$datos = $tipo_usuarios->fetch(PDO::FETCH_ASSOC);

		$id_car = $datos["id_car"];
		$nombres = $datos['nombres'];
		$apellidos = $datos['apellidos'];
		$cedula = $datos['cedula'];
		$telefono = $datos['telefono'];
		$foto_perfil = $datos['foto_perfil'];
		$contrasena = $datos['contrasena'];
		$correo = $datos['correo'];
		$estado = $datos['estado'];
	
	$query_carros = $db_con->query("SELECT * FROM carros WHERE id='$id_car'");
	$carros = $query_carros->fetch(PDO::FETCH_ASSOC);
	$placa = $carros['placa'];
	$id_tipo_car = $carros['id_tipo_car'];
	$id_fabricante = $carros['id_fabricante'];
	$id_modelo = $carros['id_modelo'];
	$id_ano = $carros['id_ano'];
	$foto_frontal = $carros['foto_frontal'];
	$foto_derecha = $carros['foto_derecha'];
	$foto_izquierda = $carros['foto_izquierda'];
	$foto_trasera = $carros['foto_trasera'];
	
	$query_tipos = $db_con->query("SELECT * FROM tipos WHERE id_tipo_car='$id_tipo_car'");
	$tipos = $query_tipos->fetch(PDO::FETCH_ASSOC);
	$tipo_car = $tipos['tipo_car'];
	
	$query_fabricantes = $db_con->query("SELECT * FROM fabricantes WHERE id_fabricante='$id_fabricante'");
	$fabricantes = $query_fabricantes->fetch(PDO::FETCH_ASSOC);
	$fabricante = $fabricantes['fabricante'];
	
	$query_modelos = $db_con->query("SELECT * FROM modelos WHERE id_modelo='$id_modelo'");
	$modelos = $query_modelos->fetch(PDO::FETCH_ASSOC);
	$modelo = $modelos['modelo'];
	
	$query_anos = $db_con->query("SELECT * FROM anos WHERE id_ano='$id_ano'");
	$anos = $query_anos->fetch(PDO::FETCH_ASSOC);
	$ano = $anos['ano'];
    	
		$datos_JSON = array("nombres"=>"$nombres","apellidos"=>"$apellidos","cedula"=>"$cedula","telefono"=>"$telefono","foto_perfil"=>"$foto_perfil","correo"=>"$correo","placa"=>"$placa");
		echo json_encode($datos_JSON); 
?>