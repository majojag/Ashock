<?php
require("conectar.php");
header('Content-Type: text/html; charset=utf-8');
html_entity_decode("UTF-8");
$cedula = $_GET["cedula"];
	$query_users = $db_con->query("SELECT * FROM usuarios WHERE cedula like '%$cedula%'");
	while($users = $query_users->fetch(PDO::FETCH_ASSOC)) {
		$id_car = $users['id_car'];
		$nombres = $users['nombres'];
		$cedula = $users['cedula'];
		$telefono = $users['telefono'];
		$apellidos = $users['apellidos'];
		$foto_perfil = $users['foto_perfil'];
		$contrasena = $users['contrasena'];
		$correo = $users['correo'];
		$estado = $users['estado'];
		echo '<p class="respuser" style="background: #EFEDED; padding: 10px 10px; border-radius: 5px; cursor: pointer" data-cedula="'.$cedula.'">'.
				'<img src="'.$foto_perfil.'" height="40" alt="">'.
				'<span class="nickname1"> '.$nombres.' </span>'.
				'<span class="fa fa-circle" style="float: right; color: #00FF00; margin-top: 11px"></span>'.
			'</p><input class="nickuser" type="text" value="'.$cedula.'" style="display: none"/>'
		;
	}
?>