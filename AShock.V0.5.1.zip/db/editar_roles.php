<?php
require("conectar.php");
header('Content-Type: text/html; charset=utf-8');
html_entity_decode("UTF-8");
@session_start();
$cedula = $_GET["cedula"];
	$query_users = $db_con->query("SELECT * FROM usuarios WHERE cedula like '%$cedula%'");
	while($users = $query_users->fetch(PDO::FETCH_ASSOC)) {
		$id_u = $users['id'];
		if ($id!=$id_u) {
			$id_car = $users['id_car'];
			$nombres = $users['nombres'];
			$cedula = $users['cedula'];
			$telefono = $users['telefono'];
			$apellidos = $users['apellidos'];
			$foto_perfil = $users['foto_perfil'];
			$contrasena = $users['contrasena'];
			$correo = $users['correo'];
			$estado = $users['estado'];
			echo '<p style="background: #EFEDED; padding: 5px 10px; border-radius: 5px">
				<img src="'.$foto_perfil.'" width="40" alt=""> 
				<span class="nickname1"> '.$nombres.' </span>
				<span class="editar" style="float: right; color: #FF7043; margin-top: 11px; cursor: pointer;" data-cedula="'.$cedula.'">Editar</span>
			</p>'
			;
		}
	}
?>