<?php
require("conectar.php");
@session_start();
$usuario = $_POST['usuario'];
$contrasena = md5($_POST['clave']);
	$login_user = $db_con->query("SELECT * FROM usuarios WHERE correo='$usuario'");
	if($login_user->rowCount() > 0){
		$login_passwd = $db_con->query("SELECT * FROM usuarios WHERE contrasena='$contrasena'");
		if($login_passwd->rowCount() > 0){
			$query_users = $db_con->query("SELECT * FROM usuarios WHERE correo='$usuario' AND contrasena='$contrasena'");
			$users = $query_users->fetch(PDO::FETCH_ASSOC);
			$_SESSION['id']=$users['id'];
				echo $_SESSION['id_perfil']=$users['id_perfil'];
		}else{
			echo "El usuario y contraseña no coincide.";
		}
	}else{
		$login_user = $db_con->query("SELECT * FROM talleres WHERE correo='$usuario'");
		if($login_user->rowCount() > 0){
			$login_passwd = $db_con->query("SELECT * FROM talleres WHERE contrasena='$contrasena'");
			if($login_passwd->rowCount() > 0){
				$query_users = $db_con->query("SELECT * FROM talleres WHERE correo='$usuario' AND contrasena='$contrasena'");
				$users = $query_users->fetch(PDO::FETCH_ASSOC);
				$_SESSION['id']=$users['id'];
				echo $_SESSION['id_perfil']=$users['id_perfil'];
			}else{
				echo "El usuario y contraseña no coincide.";
			}
			
		}else{
			echo "El usuario no se encuentra en nuestra base de datos.";
		}
	} 
?>