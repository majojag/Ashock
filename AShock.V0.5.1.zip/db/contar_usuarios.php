<?php
require("conectar.php");
@session_start();
	$usuarios= $db_con->query("SELECT * FROM usuarios WHERE id_perfil=3");
	$numero_usuarios = $usuarios->rowCount();
	$gruas = $db_con->query("SELECT * FROM usuarios WHERE id_perfil=5");
	$numero_gruas = $gruas->rowCount();
	$talleres= $db_con->query("SELECT * FROM talleres");
	$numero_talleres = $talleres->rowCount();
	
	$datos_JSON = array("numero_usuarios"=>"$numero_usuarios","numero_gruas"=>"$numero_gruas","numero_talleres"=>"$numero_talleres");
	echo json_encode($datos_JSON); 
?>