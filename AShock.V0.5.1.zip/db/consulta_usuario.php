<?php
require("conectar.php");
@session_start();
$login="";
if (isset($_SESSION['id'])) {
	$login=1;
	$id=$_SESSION['id'];
	$id_perfil=$_SESSION['id_perfil'];
	if($id_perfil==4){
		$query_users = $db_con->query("SELECT * FROM talleres WHERE id='$id'");
		$users = $query_users->fetch(PDO::FETCH_ASSOC);
		$id_perfil = $users['id_perfil'];
		$nit = $users['nit'];
		$empresa = $users['empresa'];
		$direccion = $users['direccion'];
		$correo = $users['correo'];
		$contrasena = $users['contrasena'];
		$telefono = $users['telefono'];
		$foto_taller = $users['foto_taller'];
		$hora_abierto = $users['hora_abierto'];
		$hora_cerrado = $users['hora_cerrado'];
		$dias_atencion = $users['dias_atencion'];
		$estado = $users['estado'];
	}else{
		$query_users = $db_con->query("SELECT * FROM usuarios WHERE id='$id'");
		$users = $query_users->fetch(PDO::FETCH_ASSOC);
		$id_car = $users['id_car'];
		$id_perfil = $users['id_perfil'];
		$cedula = $users['cedula'];
		$telefono = $users['telefono'];
		$nombres = $users['nombres'];
		$apellidos = $users['apellidos'];
		$foto_perfil = $users['foto_perfil'];
		$correo = $users['correo'];
		$contrasena = $users['contrasena'];
		$estado = $users['estado'];
		
		$query_carros = $db_con->query("SELECT * FROM carros WHERE id='$id_car'");
		$carros = $query_carros->fetch(PDO::FETCH_ASSOC);
		$placa = $carros['placa'];
		$id_tipo_car = $carros['id_tipo_car'];
		$id_fabricante = $carros['id_fabricante'];
		$id_modelo = $carros['id_modelo'];
		$id_ano = $carros['id_ano'];
		$foto_frontal = $carros['foto_frontal'];
		$foto_derecha = $carros['foto_derecha'];
		$foto_izquierda = $carros['foto_izquierda'];
		$foto_trasera = $carros['foto_trasera'];
		
		$query_tipos = $db_con->query("SELECT * FROM tipos WHERE id_tipo_car='$id_tipo_car'");
		$tipos = $query_tipos->fetch(PDO::FETCH_ASSOC);
		$tipo_car = $tipos['tipo_car'];
		
		$query_fabricantes = $db_con->query("SELECT * FROM fabricantes WHERE id_fabricante='$id_fabricante'");
		$fabricantes = $query_fabricantes->fetch(PDO::FETCH_ASSOC);
		$fabricante = $fabricantes['fabricante'];
		
		$query_modelos = $db_con->query("SELECT * FROM modelos WHERE id_modelo='$id_modelo'");
		$modelos = $query_modelos->fetch(PDO::FETCH_ASSOC);
		$modelo = $modelos['modelo'];
		
		$query_anos = $db_con->query("SELECT * FROM anos WHERE id_ano='$id_ano'");
		$anos = $query_anos->fetch(PDO::FETCH_ASSOC);
		$ano = $anos['ano'];
	}
	
}else{
	$login=0;
		$id_perfil = 0;
		$nit = 0;
		$empresa = 0;
		$direccion = 0;
		$correo = 0;
		$contrasena = 0;
		$telefono = 0;
		$foto_taller = 0;
		$hora_abierto = 0;
		$hora_cerrado = 0;
		$dias_atencion = 0;
		$estado = 0;
		$cedula = 0;
		$telefono = 0;
		
		$nombres = 0;
		$apellidos = 0;
		$foto_perfil = 0;
}
		?>