<?php
require("conectar.php");
header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set("America/Bogota"); 
$id = "";

	$placa = $_POST['placa_grua'];
	$id_perfil = $_POST['id_perfil'];
	$cedula = $_POST['cedula_grua'];
	$telefono = $_POST['telefono_grua'];
	$nombres = $_POST['nombres_grua'];
	$apellidos = $_POST['apellidos_grua'];
	$correo = $_POST['correo_grua'];
	$contrasena = $_POST['contra_grua'];
	$contrasena = md5($contrasena);
	$id_tipo_car = 4;
	$tipo_grua = $_POST['tipo_vehiculo_grua'];
	/*$id_fabricante = $_POST['fabricante'];
	$id_modelo = $_POST['modelos'];
	$id_ano = $_POST['anos'];*/

	$estado = "activo";

	$fecha = date("Y"). "-".date("m")."-".date("d");
	$hora = date("H").":".date("i").":".date("s");

$reporte = "error ";
$subir_foto = 0;
if ($_FILES['perfil_grua']['size']>0) {
	$file = $_FILES["perfil_grua"];
	$nombre = $file["name"];
	$array_nombre = explode('.',$nombre);
	$cuenta_arr_nombre = count($array_nombre);
	$extension = strtolower($array_nombre[--$cuenta_arr_nombre]);
	$foto = time().'_'.rand(0,99999).'.'.$extension;
    $foto_perfil = "./img/perfil/gruas/".$foto;
	$subir_foto = 1;
}else{$foto_perfil = "./img/perfil/gruas/sin_foto.png";}

$subir_foto2 = 0;
if ($_FILES['foto_grua']['size']>0) {
	$file2 = $_FILES["foto_grua"];
	$nombre2 = $file2["name"];
	$array_nombre2 = explode('.',$nombre2);
	$cuenta_arr_nombre2 = count($array_nombre2);
	$extension2 = strtolower($array_nombre2[--$cuenta_arr_nombre2]);
	$foto2 = time().'_'.rand(0,99999).'.'.$extension2;
    $foto_frontal = "./img/vehiculos/gruas/".$foto2;
	$subir_foto2 = 1;
}else{$foto_frontal = "./img/vehiculos/gruas/sin_grua.png";}

	$error1=0;
	$error2=0;
	$INSERT_carros = "INSERT INTO carros (placa, id_tipo_car, id_fabricante, id_modelo, id_ano, foto_frontal, foto_derecha, foto_izquierda, foto_trasera, tipo_grua)
	VALUES ('$placa', $id_tipo_car, '1', '1', '1', '$foto_frontal', '', '', '', '$tipo_grua')";
	
	$id_car = 0;
	if ($db_con->query($INSERT_carros)){
		$error1=1;
		$query_carros = $db_con->query("SELECT * FROM carros ORDER BY id DESC");
		$carros = $query_carros->fetch(PDO::FETCH_ASSOC);
		$id_car = $carros['id'];
	}else{
		$id_car = 0;
		$reporte = "no se puede registrar su carro";
	}

	$INSERT_users = "INSERT INTO usuarios (id_car, id_perfil, cedula, telefono, nombres, apellidos, correo, contrasena, foto_perfil, estado, fecha, hora) 
	VALUES ($id_car, $id_perfil, '$cedula', '$telefono', '$nombres', '$apellidos', '$correo', '$contrasena', '$foto_perfil', '$estado', '$fecha', '$hora')";
	if ($db_con->query($INSERT_users)){
		$error2=1;
	}
	$reporte = $error1+$error2;
	if ($reporte==2){
		if ($subir_foto==1){move_uploaded_file($file["tmp_name"], "../img/perfil/gruas/".$foto);}
		if ($subir_foto2==1){move_uploaded_file($file2["tmp_name"], "../img/vehiculos/gruas/".$foto2);}
		@session_start();
		$query_usuarios = $db_con->query("SELECT * FROM usuarios ORDER BY id DESC");
		$usuarios = $query_usuarios->fetch(PDO::FETCH_ASSOC);
		$id_u = $usuarios['id'];
		$_SESSION['id'] = $id_u;
		$id_perfil = $usuarios['id_perfil'];
		$_SESSION['id_perfil'] = $id_perfil;
		echo 1;
	}else{
		echo 'Error '.$reporte;
	}
?>