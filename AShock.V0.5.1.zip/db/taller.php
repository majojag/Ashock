<?php
require("conectar.php");
header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set("America/Bogota");

/*
$starDate = new DateTime('2018-06-01');
$endDate = new DateTime('2018-06-30');

while( $starDate <= $endDate){
	if($starDate->format('l')== 'Saturday' || $starDate->format('l')== 'Sunday'){
		echo $starDate->format('y-m-d (D)')."<br/>";
	}
	$starDate->modify("+1 days");
}
$var= date("w");
if($var == "0" ){
	echo "Es domingo";
} else if ($var == "1" ) {
	echo "Es Lunes";
} else if ($var == "2" ) {
	echo "Es Martes";
} else if ($var == "3" ) {
	echo "Es Miercoles";
} else if ($var == "4" ) {
	echo "Es Jueves";
} else if ($var == "5" ) {
	echo "Es Viernes";
} else if ($var == "6" ) {
	echo "Es Sabado";
}
*/
	$id_perfil = $_POST['id_perfil'];
	$nit = $_POST['nit'];
	$empresa = $_POST['empresa'];
	$direccion = $_POST['dir_empresa'];
	$correo = $_POST['correo_empresa'];
	$contrasena = $_POST['contra_empresa'];
	$contrasena = md5($contrasena);
	$telefono = $_POST['telefono_empresa'];
	//$placa = $_POST['placa'];
	//$id_tipo_car = $_POST['tipo_vehiculo'];
	$id_tipo_car = "";
	$estado = "activo";

	$dias_atencion = $_POST['dias_atencion'];
	$hora_abierto =  $_POST['hora_inicio'].$_POST['minuto_inicio'].$_POST['segundo_inicio'];
	$hora_cerrado =  $_POST['hora_fin'].$_POST['minuto_fin'].$_POST['segundo_fin'];

	$fecha = date("Y"). "-".date("m")."-".date("d");
	$hora = date("H").":".date("i").":".date("s");

$subir_foto = 0;
if ($_FILES['imagen_taller']['size']>0) {
	$file = $_FILES["imagen_taller"];
	$nombre = $file["name"];
	$array_nombre = explode('.',$nombre);
	$cuenta_arr_nombre = count($array_nombre);
	$extension = strtolower($array_nombre[--$cuenta_arr_nombre]);
	$foto = time().'_'.rand(0,99999).'.'.$extension;
    $foto_taller = "./img/vehiculos/talleres/".$foto;
	$subir_foto = 1;
}else{$foto_taller = "./img/vehiculos/talleres/sin_foto.png";}

	$INSERT_users = "INSERT INTO talleres (id, id_perfil, nit, empresa, direccion, correo, contrasena, telefono, foto_taller, hora_abierto, hora_cerrado, dias_atencion, estado, fecha, hora) 
	VALUES (null, '$id_perfil', '$nit', '$empresa', '$direccion', '$correo', '$contrasena', '$telefono', '$foto_taller', '$hora_abierto', '$hora_cerrado', '$dias_atencion', '$estado', '$fecha', '$hora')";
	if ($db_con->query($INSERT_users)){
		if ($subir_foto==1) {
			move_uploaded_file($file["tmp_name"], "../img/vehiculos/talleres/".$foto);
		}
		@session_start();
		$query_talleres = $db_con->query("SELECT * FROM talleres ORDER BY id DESC");
		$talleres = $query_talleres->fetch(PDO::FETCH_ASSOC);
		$id_u = $talleres['id'];
		$_SESSION['id'] = $id_u;
		$id_perfil = $talleres['id_perfil'];
		$_SESSION['id_perfil'] = $id_perfil;
		echo 1;
	}else{
		echo 'Error '.$e;
	}
?>