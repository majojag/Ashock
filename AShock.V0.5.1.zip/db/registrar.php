<?php
require("conectar.php");
header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set("America/Bogota");

	$cedula = $_POST['cedula'];
	$telefono = $_POST['telefono'];
	$nombres = $_POST['nombres'];
	$apellidos = $_POST['apellidos'];
	$correo = $_POST['correo'];
	$contrasena = $_POST['contrasena'];
	$contrasena = md5($contrasena);
	$placa = $_POST['placa'];
	$id_perfil = $_POST['id_perfil'];
	$id_tipo_car = $_POST['tipo_vehiculo'];
	$id_fabricante = $_POST['fabricante'];
	$id_modelo = $_POST['modelos'];
	$id_ano = $_POST['anos'];

	$estado = "activo";

	$fecha = date("Y"). "-".date("m")."-".date("d");
	$hora = date("H").":".date("i").":".date("s");

$reporte = "error ";
$foto_perfil = "";
$subir_foto = 0;
if ($_FILES['foto_perfil']['size']>0) {
	$file = $_FILES["foto_perfil"];
	$nombre = $file["name"];
	$array_nombre = explode('.',$nombre);
	$cuenta_arr_nombre = count($array_nombre);
	$extension = strtolower($array_nombre[--$cuenta_arr_nombre]);
	$foto = time().'_'.rand(0,99999).'.'.$extension;
    $foto_perfil = "./img/perfil/users/".$foto;
	$subir_foto = 1;
}else{$foto_perfil = "./img/perfil/users/sin_foto.png";}

$foto_frontal = "";
$subir_foto2 = 0;
if ($_FILES['foto_frontal']['size']>0) {
	$file2 = $_FILES["foto_frontal"];
	$nombre2 = $file2["name"];
	$array_nombre2 = explode('.',$nombre2);
	$cuenta_arr_nombre2 = count($array_nombre2);
	$extension2 = strtolower($array_nombre2[--$cuenta_arr_nombre2]);
	$foto2 = time().'_'.rand(0,99999).'.'.$extension2;
    $foto_frontal = "./img/vehiculos/carros/".$foto2;
	$subir_foto2 = 1;
}else{$foto_frontal = "./img/vehiculos/carros/sin-carro.jpg";}

$foto_derecha = "";
$subir_foto3 = 0;
if ($_FILES['foto_derecha']['size']>0) {
	$file3 = $_FILES["foto_derecha"];
	$nombre3 = $file3["name"];
	$array_nombre3 = explode('.',$nombre3);
	$cuenta_arr_nombre3 = count($array_nombre3);
	$extension3 = strtolower($array_nombre3[--$cuenta_arr_nombre3]);
	$foto3 = time().'_'.rand(0,99999).'.'.$extension3;
    $foto_derecha = "./img/vehiculos/carros/".$foto3;
	$subir_foto3 = 1;
}else{$foto_derecha = "./img/vehiculos/carros/sin-carro.jpg";}

$foto_izquierda = "";
$subir_foto4 = 0;
if ($_FILES['foto_izquierda']['size']>0) {
	$file4 = $_FILES["foto_izquierda"];
	$nombre4 = $file4["name"];
	$array_nombre4 = explode('.',$nombre4);
	$cuenta_arr_nombre4 = count($array_nombre4);
	$extension4 = strtolower($array_nombre4[--$cuenta_arr_nombre4]);
	$foto4 = time().'_'.rand(0,99999).'.'.$extension4;
    $foto_izquierda = "./img/vehiculos/carros/".$foto4;
	$subir_foto4 = 1;
}else{$foto_izquierda = "./img/vehiculos/carros/sin-carro.jpg";}

$foto_trasera = "";
$subir_foto5 = 0;
if ($_FILES['foto_trasera']['size']>0) {
	$file5 = $_FILES["foto_trasera"];
	$nombre5 = $file5["name"];
	$array_nombre5 = explode('.',$nombre5);
	$cuenta_arr_nombre5 = count($array_nombre5);
	$extension5 = strtolower($array_nombre[--$cuenta_arr_nombre5]);
	$foto5 = time().'_'.rand(0,99999).'.'.$extension5;
    $foto_trasera = "./img/vehiculos/carros/".$foto5;
	$subir_foto5 = 1;
}else{$foto_trasera = "./img/vehiculos/carros/sin-carro.jpg";}

	$error1=0;
	$error2=0;
	$INSERT_carros = "INSERT INTO `carros` 
	(`id`, `placa`, `id_tipo_car`, `id_fabricante`, `id_modelo`, `id_ano`, `foto_frontal`, `foto_derecha`, `foto_izquierda`, `foto_trasera`, `tipo_grua`) 
	VALUES (NULL, '$placa', $id_tipo_car, $id_fabricante, $id_modelo, $id_ano, '$foto_frontal', '$foto_derecha', '$foto_izquierda', '$foto_trasera', '')";
	
	$id_car = 0;
	if ($db_con->query($INSERT_carros)){
		$error1=1;
		$query_carros = $db_con->query("SELECT * FROM carros ORDER BY id DESC");
		$carros = $query_carros->fetch(PDO::FETCH_ASSOC);
		$id_car = $carros['id'];
	}else{
		$id_car = 0;
		$reporte = "no se puede registrar su carro";
	}

	$INSERT_users = "INSERT INTO `usuarios` (`id`, `id_car`, `id_perfil`, `cedula`, `telefono`, `nombres`, `apellidos`, `correo`, `contrasena`, `foto_perfil`, `estado`, `fecha`, `hora`) 
	VALUES (NULL, '$id_car', '$id_perfil', '$cedula', '$telefono', '$nombres', '$apellidos', '$correo', '$contrasena', '$foto_perfil', '$estado', '$fecha', '$hora')";
	if ($db_con->query($INSERT_users)){
		$error2=1;
	}
	$reporte = $error1+$error2;
	if ($reporte==2){
		@session_start();
		if ($subir_foto==1){move_uploaded_file($file["tmp_name"], "../img/perfil/users/".$foto);}
		if ($subir_foto2==1){move_uploaded_file($file2["tmp_name"], "../img/vehiculos/carros/".$foto2);}
		if ($subir_foto3==1){move_uploaded_file($file3["tmp_name"], "../img/vehiculos/carros/".$foto3);}
		if ($subir_foto4==1){move_uploaded_file($file4["tmp_name"], "../img/vehiculos/carros/".$foto4);}
		if ($subir_foto5==1){move_uploaded_file($file5["tmp_name"], "../img/vehiculos/carros/".$foto5);}
		$query_usuarios = $db_con->query("SELECT * FROM usuarios ORDER BY id DESC");
		$usuarios = $query_usuarios->fetch(PDO::FETCH_ASSOC);
		$id_u = $usuarios['id'];
		$_SESSION['id'] = $id_u;
		$id_perfil = $usuarios['id_perfil'];
		$_SESSION['id_perfil'] = $id_perfil;
		echo 1;
	}else{
		echo 'Error '.$e;
	}
?>