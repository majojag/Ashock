<?php
			@session_start();
			if (isset($_SESSION['id_perfil'])) {
				$id_perfil=$_SESSION['id_perfil'];
				if($id_perfil==1){ header('Location: dashboard.php'); }
				if($id_perfil==2){ header('Location: dashboard.php'); }
				if($id_perfil==3){ header('Location: usuarios.php'); }
				if($id_perfil==4){ header('Location: taller.php'); }
				if($id_perfil==5){ header('Location: grua.php'); }
			}else{
				$id_perfil=0;
				header('Location: registrar.php');
			}
?>