<?php
//header('Location: registrar.php');
	$mantenimiento="off";
	if($mantenimiento=="off"){
		require("db/validador.php");
	}else{
		echo "No disponible";
	}
?>