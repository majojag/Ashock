<!DOCTYPE html>
<html>
	<head>
		
		<?php
			@session_start();
			if (isset($_SESSION['id_perfil'])) {
				$id_perfil=$_SESSION['id_perfil'];
				if($id_perfil==3){ header('Location: usuarios.php'); }
				if($id_perfil==4){ header('Location: taller.php'); }
				if($id_perfil==5){ header('Location: grua.php'); }
			}else{header('Location: registrar.php');}
		/* ----- plugins -----*/
			require("db/conectar.php");
		//	require("db/contar_usuarios.php");
			require("ext/metas.php");
			require("config_taller.php");
			require("ext/styles.php");
			require("ext/scripts.php");
		/* ----- plugins -----*/
		/* ------- CSS --------*/
			echo 
				$favicon.
				$bootstrap_css.
				$font_awesome.
				$estructure.
				$style_css.
				$responsive_css.
				$jcalender_css.
				$recurso_style
			;
		/* ------- CSS --------*/
		/* -------- JS --------*/
			echo 
				$jquery.
				$bootstrap_js.
				$main.
				$imagenes_js.
				$dashboard_js.
				$recursos_script_js.
				$Key
			;
		/* -------- JS --------*/
		?>
		
	</head>
	<body>
		<div id="wrapper">
			<div class="overlay"></div>
			<!-- Sidebar -->
			<nav class="navbar navbar-inverse navbar-fixed-top menu-dashboard" id="sidebar-wrapper" role="navigation">				
				<ul class="nav sidebar-nav">
					<li id="pcontrol" class="active">
						<a href="#">Panel de control</a>
					</li>
					<li id="usuarios">
						<a href="#">Usuarios</a>
					</li>
					<li id="chat">
						<a href="#">Chat</a>
					</li>
					<li id="roles">
						<a href="#">Roles</a>
					</li>
					<li id="talleres">
						<a href="#">Auto Talleres</a>
					</li>
					<li id="gruas">
						<a href="#">Servicio de grua</a>
					</li>
					<hr width="100%"><br>
					<center style="clear:both;">
						<img src="img/logo.png" width="45%" alt="">
					</center>
					<h4 align="center">Ashock</h4>
				</ul>
			</nav>
		<!-- /#sidebar-wrapper -->
			<!-- Page Content -->
			<div id="page-content-wrapper">
				
				<div id="home" style="background: #FFFFFF">
					<header>
						<div class="header-top clearfix">
							<a class="l-left toggle-menu" href="#">
								<button type="button" class="hamburger is-closed" data-toggle="offcanvas">
									<span class="hamb-top"></span>
									<span class="hamb-middle"></span>
									<span class="hamb-bottom"></span>
								</button><img style="margin-left: 80px" src="img/logo_dash.png" height="40" alt="">
							</a>
							<ul class="nav navbar-nav menus pull-right">
								<li class="nav navbar-nav menus dropdown" style="margin-left: -80px;">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="color: #FCF0F1">
									<h4>Admin <span class="caret"></span></h4></a>
									<ul class="dropdown-menu" style="margin-left: -50px;">
										<li><a href="#">Mi Cuenta (editar)</a></li>
										<li role="separator" class="divider"></li>
										<li class="cerrar"><a href="#">Cerrar Sesión</a></li>
									</ul>
								</li>
							</ul>
						</div>
					</header>
					<div id="cpanel">
						<div class="container"><br>
							<h2 class="titulodash">Panel de control</h2><br>
								<div id="map1" style="height: 400px"></div><br><br>
							<h3 align="center">
								<span c<h3 align="center">
								<span class="l-left cpanel-count-users">Usuarios activos <span id="numero_usuarios">0</span></span>
								<span class="cpanel-count-gruas">Gruas activas <span id="numero_gruas">0</span></span>
								<span class="l-right cpanel-count-tallers">Carrotalleres activos <span id="numero_talleres">0</span></span>
							</h3>
						</div>
					</div>
					<div id="usuario-a" class="hidden">
						<div class="container">
							<h2 class="titulodash">Usuarios 
								<span class="fa fa-plus" data-toggle="modal" data-target="#crear_usuarios" style="cursor:pointer;"></span>
							</h2><br>
							<div class="col-sm-12 col-md-6 col-lg-6">
								<h4>Mapa en tiempo real</h4>
								<div id="map2" style="height: 400px"></div>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6">
								<p>Detalle </p>
								<h4>Busqueda  de usuarios</h4>
								<form class="navbar-form">
									<input type="number" class="form-control search-user" placeholder="Ingresa el número de cédula sin . 00000">
									<div class="getusers" style="max-height: 200px; overflow-y: scroll; display: none"></div>
									<br><button type="button" class="btn btn-succes btn-search-users">Buscar</button><br>
								</form>
								<br>
								<div id="crear" style="border: 2px solid #474747; border-radius: 5px; padding: 40px; display: none">
									
								</div>
								<div id="editar" style="border: 2px solid #474747; border-radius: 5px; padding: 0px 10px 20px; display: none">
									<form action="" class="group-form">
										<table style="width: 100%">
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Marca Modelo Años </label> </p> 
												</td>
												<td style="width: 50% !important">
													<select id="marca_form1" name="marca" class="col-lg-4">
														<option value="">Seleccionar</option>
													</select>
													<select id="modelo_form1" name="modelo" class="col-lg-4">
														<option value="">Seleccionar</option>
													</select>
													<select id="ano_form1" name="ano" class="col-lg-4">
														<option value="">Seleccionar</option>
													</select>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Placa</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input id="placa_form1" type="text" class="form-control" aria-label="xs"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Nombres</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input id="nombres_form1" type="text" class="form-control" aria-label="xs"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Apellidos</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input id="apellidos_form1" type="text" class="form-control" aria-label="xs"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Cedula</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input id="cedula_form1" type="text" class="form-control" aria-label="xs"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Correo Electrónico</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input id="correo_form1" type="text" class="form-control" aria-label="xs"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Historial de Servicios</label></p>
												</td>
												<td>
													<p><span class="fa fa-plus botonpequeno" style="cursor:pointer;" data-toggle="modal" data-target="#historialservicios"></span></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Servicios</label></p>
												</td>
												<td style="width: 50% !important">
													<p><span class="fa fa-plus botonpequeno" style="cursor:pointer;" data-toggle="modal" data-target="#servicios"></span></p>
												</td>
											</tr>
											<br>
											<tr>
												<td style="width: 50% !important;padding-top: 20px;">
													<button style="float: right; margin-right: 10px;" type="button" class="btn btn-succes">Editar</button>
												</td>
												<td style="width: 50% !important;padding-top: 20px;">
													<button style="margin-left: 10px;" type="button" class="btn btn-succes">Guardar</button>
												</td>
											</tr>
										</table>
									</form>
								</div>
							</div>
						</div>
<!-- Modal -->
<div id="crear_usuarios" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Creacion de Nuevo Usuario</h4>
      </div>
      <div class="modal-body">
        
        
        
									<form action="" class="group-form">
										<table style="width: 100%">
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Marca Modelo Años </label> </p> 
												</td>
												<td style="width: 50% !important">
													<select id="marca_form1" name="marca" class="form-control">
														<option value="">Seleccionar</option>
													</select>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Marca Modelo Años </label> </p> 
												</td>
												<td style="width: 50% !important">
													<select id="modelo_form1" name="modelo" class="form-control">
														<option value="">Seleccionar</option>
													</select>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Marca Modelo Años </label> </p> 
												</td>
												<td style="width: 50% !important">
													<select id="ano_form1" name="ano" class="form-control">
														<option value="">Seleccionar</option>
													</select>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Placa</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input id="placa" type="text" class="form-control" aria-label="xs"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Nombres</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input id="nombres" type="text" class="form-control" aria-label="xs"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Apellidos</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input id="apellidos" type="text" class="form-control" aria-label="xs"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Cedula</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input id="cedula" type="text" class="form-control" aria-label="xs"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Correo Electrónico</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input id="correo" type="text" class="form-control" aria-label="xs"></p>
												</td>
											</tr>
										</table>
									</form>
        
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Guardar </button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div id="historialservicios" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Historial de Servicios</h4>
      </div>
      <div class="modal-body">
        <p>Aún no hay servicios solicitados.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div id="servicios" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Historial de Servicios</h4>
      </div>
      <div class="modal-body">
      
        <p>Servicio de Taller
        <!-- Rounded switch -->
	<label style="float:right;" class="switch">
	  <input type="checkbox">
	  <span class="slider round"></span>
	</label> </p>
        <p>Servicio de Grua 
        <!-- Rounded switch -->
	<label style="float:right;" class="switch">
	  <input type="checkbox">
	  <span class="slider round"></span>
	</label></p>
        <p>Servicio de Asistente de choque
        <!-- Rounded switch -->
	<label style="float:right;" class="switch">
	  <input type="checkbox">
	  <span class="slider round"></span>
	</label></p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Aceptar</button>
      </div>
    </div>
  </div>
</div>
					</div>
					<div id="chat-a" class="hidden">
						<div style="padding: 80px">
							<h2>Chat</h2>
							<!--<div class="row">
								<div class="col-sm-12 col-md-6 col-lg-6" style="padding: 0px">
									<p>Busqueda  de usuarios</p>
									<form class="navbar-form" style="width: 100%">
										<div class="form-group" style="width: 100%">
											<input type="number" class="form-control" placeholder="Ingresa el número de cédula sin . 00000" style="border: 2px solid #999; width: 100% !important">
										</div><br><br>
										<button type="button" class="btn btn-succes btn-search-users">Buscar</button>
									</form><br>
								</div>
								<div class="col-sm-12 col-md-6 col-lg-6" style="padding: 0px">
								</div>
							</div>-->
							<p>Todos los usuarios</p>
							<div class="row">
								<div class="col-sm-12 col-md-6 col-lg-6" style="padding: 0px">
									<div id="user_chat" style="border: 2px solid #888; border-radius: 5px; padding: 10px;">
										
									</div>
								</div>
								<div class="col-sm-12 col-md-6 col-lg-6" style="padding: 0px">
									<div class="chating" style="border: 2px solid #888; border-radius: 5px; padding: 0px;">
										<div class="headchat" style="background: #F9F9F9; padding: 8px 12px; border: 1px solid #999999;">
											<img id="catimg" src="img/perfil/users/sin_foto.png" width="40" alt=""> 
											<span id="nickname1">Usuario </span><span id="estado">Usuario </span>
											<span class="" style="float: right; color: #999999; margin-top: 6px; font-size: 26px;">x</span>
										</div>
										<div id="bodychat" class="bodychat" style="padding: 40px; height:400px; overflow-y:scroll">
										</div>
										<audio id="audio" class="hidden">
											<source type="audio/mp3" src="sound/sms.mp3">
											<source type="audio/ogg" src="sound/sms.ogg">
											<source type="audio/aac" src="sound/sms.aac">
											<source type="audio/wav" src="sound/sms.wav">
										</audio>
										<div class="footerchat" style="background: #F9F9F9; border: 1px solid #999999;">
											<p align="center">
												<label for="chat_up_file" style="cursor: pointer; float: left">
													<i class="fa fa-plus" style="padding: 5px; margin: 5px 8px; font-size: 24px; color: #FFFFFF; background-color: #0076D6; border-radius: 100%;"></i>
												</label>
												<input id="chat_up_file" type="file" name="foto" style="display: none; cursor: pointer !important;">
												<input id="message" class="message" type="text" name="message" placeholder="Escribir mensaje ..." style="margin-top: 8px; cursor: pointer !important; font-size: 26px; border: 0px; width:80%;">
												<i class="fa fa-send" style="padding: 15px; font-size: 28px; color: #0076D6; background: none; border-radius: 100%; float: right;"></i>
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>		
					</div>
					<div id="roles-a" class="hidden">
						<div class="container">
							<h2 class="titulodash">Roles 
								<span class="fa fa-plus" ></span>
							</h2><br>
									<p>Busqueda  de usuarios</p>
									<form class="navbar-form">
										<input type="number" id="search-roles" class="form-control" placeholder="Ingresa el número de cédula sin . 00000" style="border: 2px solid #999; width: 49% !important">
										<br><br> 
										<button type="button" class="btn btn-succes">Buscar</button>
									</form><br>
							<div class="col-sm-12 col-md-6 col-lg-6">
								<p>Todos los usuarios </p>
								<div id="editar_usuarios" style="border: 2px solid #888; border-radius: 5px; padding: 10px;">
									
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6">
								<p>Detalle </p>
								<div style="border: 2px solid #888; border-radius: 5px; padding: 40px;">
									<form action="" class="group-form">
										<table>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Marca Modelo Años </label> </p> 
												</td>
												<td style="width: 50% !important">
													<select id="marca_form2" name="marca" class="col-lg-4">
														<option value="">Seleccionar</option>
													</select>
													<select id="modelo_form2" name="modelo" class="col-lg-4">
														<option value="">Seleccionar</option>
													</select>
													<select id="ano_form2" name="ano" class="col-lg-4">
														<option value="">Seleccionar</option>
													</select>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Placa</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input type="text" class="form-control" id="placa_form2"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Nombres</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input type="text" class="form-control" id="nombres_form2"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Apellidos</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input type="text" class="form-control" id="apellidos_form2"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Cedula</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input type="text" class="form-control" id="cedula_form2"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Teléfono</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input type="text" class="form-control" id="telefono_form2"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Correo Electrónico</label></p>
												</td>
												<td style="width: 50% !important">
													<p><input type="text" class="form-control" id="correo_form2"></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Historial de Servicios</label></p>
												</td>
												<td>
													<p><span class="fa fa-plus botonpequeno"></span></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<p><label for="">Servicios</label></p>
												</td>
												<td style="width: 50% !important">
													<p><span class="fa fa-plus botonpequeno"></span></p>
												</td>
											</tr>
											<tr>
												<td style="width: 50% !important">
													<button style="float: right; margin-right: 10px;" type="button" class="btn btn-succes">Editar</button>
												</td>
												<td style="width: 50% !important">
													<button style="margin-left: 10px;" type="button" class="btn btn-succes">Guardar</button>
												</td>
											</tr>
										</table>
									</form>
								</div>
							</div>
						</div>
					</div>
					<div id="auto-taller" class="hidden">
						<div class="" style="padding: 10px 100px;">
							<h2>Mapa Auto taller 
								<span class="fa fa-plus" style="background: #006DAA; color: #FFFFFF; border-radius: 100%; padding: 15px; float: right"></span>
							</h2><br>
							<!--<p>Busqueda  de usuarios</p>
							<form class="navbar-form">
								<input type="number" class="form-control" placeholder="Ingresa el número de cédula sin . 00000" style="border: 1px solid #999; width: 50% !important">
								<br><br>
								<button type="button" class="btn btn-succes">Buscar</button>
							</form><br>
							<p>Todos los usuarios </p> -->
							<div class="col-sm-12 col-md-12 col-lg-12" style="border: 2px solid #888; border-radius: 5px; height:660px">
								<!-- Display event calendar -->
								<div id="calendar_div">
									<?php echo getCalender(); ?>
								</div><br><br><br><br>
									<!-- Display event calendar -->
							</div>
							<div class="col-sm-12 col-md-12 col-lg-12">
								<div class="chating" style="border: 2px solid #888; border-radius: 5px; padding: 0px;">
									<div class="headchat" style="background: #F9F9F9; padding: 8px 12px; height: 60px; border: 1px solid #999999;">
										<div class="col-lg-4"><h4 align="center">Carro taller</h3></div>
										<div class="col-lg-4"><h4 align="center">Cliente</h3></div>
										<div class="col-lg-4"><h4 align="center">Hora y Fecha</h3></div>
									</div>
									<div class="bodycchat" style="padding:30px;">
										<div class="row" style="padding:0px;margin:0px">
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Taller Norte</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Pepito Perez</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">26-Jul 18-4:30 pm</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="right" class="fa fa-circle" style="position: relative;color: #00FF00;padding: 3px;float: right;top: 6px;"></p> 
												<span class="editar" style="float: right; color: #FF7043; margin-top: 4px">Editar</span>
											</div>
										</div>
										<div class="row" style="padding:0px;margin:0px">
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Taller Norte</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Pepito Perez</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">26-Jul 18-4:30 pm</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="right" class="fa fa-circle" style="position: relative;color: #00FF00;padding: 3px;float: right;top: 6px;"></p> 
												<span class="editar" style="float: right; color: #FF7043; margin-top: 4px">Editar</span>
											</div>
										</div>
										<div class="row" style="padding:0px;margin:0px">
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Taller Norte</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Pepito Perez</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">26-Jul 18-4:30 pm</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="right" class="fa fa-circle" style="position: relative;color: #00FF00;padding: 3px;float: right;top: 6px;"></p> 
												<span class="editar" style="float: right; color: #FF7043; margin-top: 4px">Editar</span>
											</div>
										</div><br><br><br><br><br><br><br><br><br><br><br><br>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="servicio-grua" class="hidden">
						<div style="padding: 10px 80px">
							<h2 class="titulodash">Usuarios (Grúa)
								<span class="fa fa-plus"></span>
							</h2><br>
							<div class="row">
								<div class="col-sm-12 col-md-6 col-lg-6">
									<p>Mapa en tiempo real</p>
									<div id="map3" style="height: 400px"></div>
								</div>
								<div class="col-sm-12 col-md-6 col-lg-6">
									<p>Busqueda  de usuarios</p>
									<form class="navbar-form">
										<input id="search-gruas" type="number" class="form-control" placeholder="Ingresa el número de cédula sin . 00000" style="border: 1px solid #999; width: 100% !important">
										<div class="getgruas" style="max-height: 200px; overflow-y: scroll; display: none"></div>
										<br><br>
										<button type="button" class="btn btn-succes">Buscar</button>
									</form><br>
									<p>Detalle </p>
									<div style="border: 2px solid #888; border-radius: 5px; padding: 40px;">
										<form action="" class="group-form">
											<table style="width: 100%">
												<tr>
													<td style="width: 50% !important">
														<p><label for="">Marca Modelo Años </label> </p> 
													</td>
													<td style="width: 50% !important">
														<select id="marca_form3" name="marca" class="col-lg-4">
															<option value="">Seleccionar</option>
														</select>
														<select id="modelo_form3" name="modelo" class="col-lg-4">
															<option value="">Seleccionar</option>
														</select>
														<select id="ano_form3" name="ano" class="col-lg-4">
															<option value="">Seleccionar</option>
														</select>
													</td>
												</tr>
												<tr>
													<td style="width: 50% !important">
														<p><label for="">Placa</label></p>
													</td>
													<td style="width: 50% !important">
														<p><input type="text" class="form-control" id="placa_form3"></p>
													</td>
												</tr>
												<tr>
													<td style="width: 50% !important">
														<p><label for="">Nombres</label></p>
													</td>
													<td style="width: 50% !important">
														<p><input type="text" class="form-control" id="nombres_form3"></p>
													</td>
												</tr>
												<tr>
													<td style="width: 50% !important">
														<p><label for="">Apellidos</label></p>
													</td>
													<td style="width: 50% !important">
														<p><input type="text" class="form-control" id="apellidos_form3"></p>
													</td>
												</tr>
												<tr>
													<td style="width: 50% !important">
														<p><label for="">Cedula</label></p>
													</td>
													<td style="width: 50% !important">
														<p><input type="text" class="form-control" id="cedula_form3"></p>
													</td>
												</tr>
												<tr>
													<td style="width: 50% !important">
														<p><label for="">Teléfono</label></p>
													</td>
													<td style="width: 50% !important">
														<p><input type="text" class="form-control" id="telefono_form3"></p>
													</td>
												</tr>
												<tr>
													<td style="width: 50% !important">
														<p><label for="">Correo Electrónico</label></p>
													</td>
													<td style="width: 50% !important">
														<p><input type="text" class="form-control" id="correo_form3"></p>
													</td>
												</tr>
												<tr>
													<td style="width: 50% !important">
														<p><label for="">Historial de Servicios</label></p>
													</td>
													<td>
														<p><span class="fa fa-plus" style="background: #006DAA; color: #FFFFFF; border-radius: 100%; padding: 5px"></span></p>
													</td>
												</tr>
												<tr>
													<td style="width: 50% !important">
														<button style="float: right; margin-right: 10px;" type="button" class="btn btn-succes">EDITAR</button>
													</td>
													<td style="width: 50% !important">
														<button style="margin-left: 10px;" type="button" class="btn btn-succes">GUARDAR</button>
													</td>
												</tr>
											</table>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<!-- /#page-content-wrapper -->
			
		</div>
		<script type="text/javascript" src="https://ashock.app:3000/socket.io/socket.io.js"></script>
	</body>
						<script>
						function initMap() {
						        var map1 = new google.maps.Map(document.getElementById('map1'), {
						          center: {lat: 4.677424, lng: -74.048205},
						          zoom: 16
						        });
						        var map2 = new google.maps.Map(document.getElementById('map2'), {
						          center: {lat: 4.677424, lng: -74.048205},
						          zoom: 16
						        });
						        var map3 = new google.maps.Map(document.getElementById('map3'), {
						          center: {lat: 4.677424, lng: -74.048205},
						          zoom: 16
						        });
							/*
						        var DivMap = document.getElementById('map');
						        if (navigator.geolocation) {
						          navigator.geolocation.getCurrentPosition(function(position) {
						           
								lat=position.coords.latitude;
								lon=position.coords.longitude;
		
								var Glatlon = new google.maps.LatLng( lat, lon );
		
								var ConfigMap = {
									zoom: 18,
									center: Glatlon
								};
								
								var GMap = new google.maps.Map( DivMap, ConfigMap );
								
								var Grua1 = {
									position: Glatlon,
									map: GMap,
									title: "eres tu",
									fillOpacity: .9,
									animation: google.maps.Animation.DROP
								};							
								var IconGrua1 = new google.maps.Marker( Grua1);
								IconGrua1.setIcon( "img/icons/grua.png" );
								
						          }, function() {
						            handleLocationError(true, infoWindow, map.getCenter());
						          });
						        }else{
						        	alert("sin gps");
						        }
						*/						           
						
							var Grua1 = {
								position: {lat: 4.675324, lng: -74.048895},
								map: map1,
								title: "Grua 1",
								fillOpacity: .9,
								animation: google.maps.Animation.DROP
							};							
							var IconGrua1 = new google.maps.Marker( Grua1);
							IconGrua1.setIcon( "img/icons/grua.png" );
							var Grua2 = {
								position: {lat: 4.677494, lng: -74.041125},
								map: map1,
								title: "Grua 2",
								fillOpacity: .9,
								animation: google.maps.Animation.DROP
							};							
							var IconGrua2 = new google.maps.Marker( Grua2);
							IconGrua2.setIcon( "img/icons/grua.png" );
							
							var Grua3 = {
								position: {lat: 4.677494, lng: -74.049165},
								map: map1,
								title: "Grua 3",
								fillOpacity: .9,
								animation: google.maps.Animation.DROP
							};
							
							var IconGrua3 = new google.maps.Marker( Grua3);
							IconGrua3.setIcon( "img/icons/grua.png" );
							
							var Taller1 = {
								position: {lat: 4.672213, lng: -74.048789},
								map: map1,
								title: "Taller 1",
								fillOpacity: .9,
								animation: google.maps.Animation.DROP
							};							
							var IconTaller1 = new google.maps.Marker(Taller1);
							IconTaller1.setIcon( "img/icons/taller.png" );
							
							var Taller2 = {
								position: {lat: 4.679190, lng: -74.049895},
								map: map1,
								title: "Taller 2",
								fillOpacity: .9,
								animation: google.maps.Animation.DROP
							};							
							var IconTaller2 = new google.maps.Marker(Taller2);
							IconTaller2.setIcon( "img/icons/taller.png" );
							
							var Taller3 = {
								position: {lat: 4.678513, lng: -74.048189},
								map: map1,
								title: "Taller 3",
								fillOpacity: .9,
								animation: google.maps.Animation.DROP
							};
							
							var IconTaller3 = new google.maps.Marker(Taller3);
							IconTaller3.setIcon( "img/icons/taller.png" );
						}
						</script>
		    				<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVHQ-vbUvaGZQUx5MweCwlE8oMwVieIAw&callback=initMap" async defer></script>
</html>
