	
	<?php
		$favicon = '<link rel="icon" type="image/x-icon" href="./favicon.ico">';
		$bootstrap_css = '<link rel="stylesheet" id="bootstrap-css" href="./ext/css/bootstrap.min.css">';
		$font_awesome = '<link rel="stylesheet" type="text/css" href="ext/css/font-awesome.css" />';

		$estructure = '<link rel="stylesheet" type="text/css" href="ext/css/estructure.css" />';
		$style_css = '<link rel="stylesheet" type="text/css" href="ext/css/style.css" />';
		$responsive_css = '<link rel="stylesheet" type="text/css" href="ext/css/responsive.css" />';

		$jcalender_css = '<link rel="stylesheet" type="text/css" href="ext/css/jcalender.css">';
		$recurso_style = '<link rel="stylesheet" type="text/css" href="css/recurso-style.css">';
	?>