$(document).ready(function() {
// JavaScript Document
	'use strict';
	
	$.getJSON('db/tipo_vehiculo.php',function(tipo_vehiculo){
		$.each(tipo_vehiculo, function(id,tipo){
			$("#tipo_vehiculo").append('<option value="'+id+'">'+tipo+'</option>');
		});
	});
	$.getJSON('db/fabricante_vehiculo.php',function(fabricante_vehiculo){
		$.each(fabricante_vehiculo, function(id,fabricante){
			$("#fabricante").append('<option value="'+id+'">'+fabricante+'</option>');
		});
	});
	$("#fabricante").change(function() {$("#modelos").html('');
		$.getJSON('db/modelo_vehiculo.php?id_fabricante='+$("#fabricante").val(),function(modelos){
			$.each(modelos, function(id,modelo){
				$("#modelos").append('<option value="'+id+'">'+modelo+'</option>');
			});
		});
    });
	$.getJSON('db/ano_vehiculo.php',function(anos_vehiculo){
		$.each(anos_vehiculo, function(id,ano){
			$("#anos").append('<option value="'+id+'">'+ano+'</option>');
		});
	});
	
	$(".guardar").click(function(){
		var formData = new FormData($("#registrer-usuario")[0]);
		$.ajax({
			url  : 'db/registrar.php',
			type : 'POST',
			contentType: false,
			processData: false,
			data: formData,
			beforeSend: function(){
				$("#guardar").attr("disabled");
				$("#error").html('');
				$("#error").html('<div class="alert alert-warning" role="alert"> Cargando ... </div>');
			},
			success : function(response){
				if(response=="1"){
					$(".error").html('');
					$(".error").html('<div class="alert alert-success" role="alert"> El usuario se registró con éxito. Cargado... </div>');
					location.href='index.php';
				}else{
					$("#btn-login").html('Error');
					$("#error").html('');
					$("#error").html('<div class="alert alert-danger" role="alert"> '+response+' </div>');
				}
		   }
		});
		return false;
	});
	$(".guardar_taller").click(function(){
		var formData = new FormData($("#register-taller")[0]);
		$.ajax({
			url  : 'db/taller.php',
			type : 'POST',
			contentType: false,
			processData: false,
			data: formData,
			beforeSend: function(){
				$("#guardar_taller").attr("disabled");
				$("#error_taller").html('');
				$("#error_taller").html('<div class="alert alert-warning" role="alert"> Cargando ... </div>');
			},
			success : function(response){
				if(response=="1"){
					$("#error_grua").html('');
					$("#error_grua").html('<div class="alert alert-success" role="alert"> El usuario se registró con éxito. </div>');
					location.href='taller.php';
				}else{
					$("#guardar_taller").html('Error');
					$("#error_taller").html('');
					$("#error_taller").html('<div class="alert alert-danger" role="alert"> '+response+' </div>');
				}
		   }
		});
		return false;
	});
	$(".guardar_grua").click(function(){
		var formData = new FormData($("#regis-grua")[0]);
		$.ajax({
			url  : 'db/grua.php',
			type : 'POST',
			contentType: false,
			processData: false,
			data: formData,
			beforeSend: function(){
				$("#guardar_grua").attr("disabled");
				$("#error_grua").html('');
				$("#error_grua").html('<div class="alert alert-warning" role="alert"> Cargando ... </div>');
			},
			success : function(response){
				if(response=="1"){
					$("#error_grua").html('');
					$("#error_grua").html('<div class="alert alert-success" role="alert"> El usuario se registró con éxito. </div>');
					location.href='grua.php';
				}else{
					$("#guardar_grua").html('Error');
					$("#error_grua").html('');
					$("#error_grua").html('<div class="alert alert-danger" role="alert"> '+response+' </div>');
				}
		   }
		});
		return false;
	});
});