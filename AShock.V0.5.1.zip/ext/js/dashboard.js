$(document).ready(function() {
  // variables
	"use strict";
	var socket = io.connect('https://ashock.app:3000');
	
  $("#pcontrol").click(function () {
	$("#pcontrol").addClass("active");
	$("#cpanel").removeClass("hidden");
	$("#usuarios").removeClass("active");
	$("#usuario-a").addClass("hidden");
	$("#chat").removeClass("active");
	$("#chat-a").addClass("hidden");
	$("#roles").removeClass("active");
	$("#roles-a").addClass("hidden");
	$("#talleres").removeClass("active");
	$("#auto-taller").addClass("hidden");
	$("#gruas").removeClass("active");
	$("#servicio-grua").addClass("hidden");
  });
  $("#usuarios").click(function () {
	$("#pcontrol").removeClass("active");
	$("#cpanel").addClass("hidden");
	$("#usuarios").addClass("active");
	$("#usuario-a").removeClass("hidden");
	$("#chat").removeClass("active");
	$("#chat-a").addClass("hidden");
	$("#roles").removeClass("active");
	$("#roles-a").addClass("hidden");
	$("#talleres").removeClass("active");
	$("#auto-taller").addClass("hidden");
	$("#gruas").removeClass("active");
	$("#servicio-grua").addClass("hidden");
  });
  $("#chat").click(function () {
	$("#pcontrol").removeClass("active");
	$("#cpanel").addClass("hidden");
	$("#usuarios").removeClass("active");
	$("#usuario-a").addClass("hidden");
	$("#chat").addClass("active");
	$("#chat-a").removeClass("hidden");
	$("#roles").removeClass("active");
	$("#roles-a").addClass("hidden");
	$("#talleres").removeClass("active");
	$("#auto-taller").addClass("hidden");
	$("#gruas").removeClass("active");
	$("#servicio-grua").addClass("hidden");
  });
  $("#roles").click(function () {
	$("#pcontrol").removeClass("active");
	$("#cpanel").addClass("hidden");
	$("#usuarios").removeClass("active");
	$("#usuario-a").addClass("hidden");
	$("#chat").removeClass("active");
	$("#chat-a").addClass("hidden");
	$("#roles").addClass("active");
	$("#roles-a").removeClass("hidden");
	$("#talleres").removeClass("active");
	$("#auto-taller").addClass("hidden");
	$("#gruas").removeClass("active");
	$("#servicio-grua").addClass("hidden");
  });
  $("#talleres").click(function () {
	$("#pcontrol").removeClass("active");
	$("#cpanel").addClass("hidden");
	$("#usuarios").removeClass("active");
	$("#usuario-a").addClass("hidden");
	$("#chat").removeClass("active");
	$("#chat-a").addClass("hidden");
	$("#roles").removeClass("active");
	$("#roles-a").addClass("hidden");
	$("#talleres").addClass("active");
	$("#auto-taller").removeClass("hidden");
	$("#gruas").removeClass("active");
	$("#servicio-grua").addClass("hidden");
  });
  $("#gruas").click(function () {
	$("#pcontrol").removeClass("active");
	$("#cpanel").addClass("hidden");
	$("#usuarios").removeClass("active");
	$("#usuario-a").addClass("hidden");
	$("#chat").removeClass("active");
	$("#chat-a").addClass("hidden");
	$("#roles").removeClass("active");
	$("#roles-a").addClass("hidden");
	$("#talleres").removeClass("active");
	$("#auto-taller").addClass("hidden");
	$("#gruas").addClass("active");
	$("#servicio-grua").removeClass("hidden");
  });
});