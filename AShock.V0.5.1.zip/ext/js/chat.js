$(document).ready(function() {
// JavaScript Document
	'use strict';
	var socket = io.connect('https://ashock.app:3000');
	
	var sms = document.getElementById("audio");
	
	var id = $("#chatid").val();
	var perfil = $("#chatid_perfil").val();
	var foto = $("#chatfoto_perfil").val();
	var username = document.getElementById("chatcorreo");
	var message = document.getElementById("message");
	/*
	var nombres = document.getElementById('chatnombres');
	var apellidos = document.getElementById('chatapellidos');
	//var nombrecompleto = nombres.value+" "+apellidos.value;
	
	
function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}            

var dt = new Date();
var month = dt.getMonth()+1;
var day = dt.getDate();
var year = dt.getFullYear();
//var dateTime = month + '-' + day + '-' + year;

*/
	function chat(){
		socket.emit('chatsend:message', {
			id: id,
			perfil: perfil,
			username: username.value,
			message: message.value,
			foto: foto
		});
		$("#message").val("");
	}
	
socket.on('chatget:message', function (data) {
		if(data.perfil === 1){
				var get_message =
					'<p id="sms" align="left">'+
						'<div class="get_message">'+data.message+'</div>'+
					'</p>';
				sms.play();
				$("#fullpage2").append(get_message).scrollTop($("#fullpage2").prop('scrollHeight'));
		}else{
			if(data.id === id){
				var send_message =
					'<p id="sms" align="right">'+
						'<div class="send_message" style="">'+data.message+'</div>'+
						'<img src="'+foto+'" width="45" style="position: relative; top: -67px; float: left;" alt="">'+
					'</p>';
				$("#fullpage2").append(send_message).scrollTop($("#fullpage2").prop('scrollHeight'));
			}
		}
});
	
	
	socket.on('query:user', function(dato) {
		$("#chatusername").text(dato.nombrecompleto);
		$("#chatfoto").attr("src",dato.foto);
	});
	$(".fa-send").click(function(){
		if ($("#message").val() != "") {
			chat();
		}	
	});
	$("#message").focus(function () {
		$("#message").keypress(function (e) {
			if (e.which === 13) {
				if ($("#message").val() != "") {
					chat();
				}
			}
		});
	});
	$("#message").keyup(function(){
		socket.emit('chat:writing', {
			username: username.value,
			foto: foto
		});
	});
	socket.on('chat:writing', function(dato) {
		$("#chatusername").text(dato.username);
		$("#chatfoto").attr("src",dato.foto);
		$("#estado").text(' esta escribiendo...');
		setTimeout(function(){
			$("#estado").text('');
		},2000);
	});
	
	function chat_up_file(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					var send_img =	
						'<p align="left">'+
							'<div class="send_message"><img src="'+e.target.result+'" width="100%" alt=""></div>'+
					'<img src="img/logo.png" width="45" style="position: relative; top: -67px; float: left;" alt="">'+
						'</p>';
					$("#fullpage2").append(send_img);
				};
			})(f);
			reader.readAsDataURL(f);
		}
	}
	$('#chat_up_file').change(chat_up_file);
	/*
	*/
	
});