	var map, infoWindow;
    var DivMap1 = document.getElementById('map1');
    var DivMap2 = document.getElementById('map2');
      function initMap() {
        map = new google.maps.Map(document.getElementById('map1'), {
          center: {lat: 4.5783445, lng: -74.0768145},
          zoom: 16
        });
        infoWindow = new google.maps.InfoWindow;

        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
           
		lat=position.coords.latitude;
		lon=position.coords.longitude;
		
		var Glatlon = new google.maps.LatLng( lat, lon );
		
		var ConfigMap = {
			zoom: 17,
			center: Glatlon
		};
		
		var GMap = new google.maps.Map( DivMap1, ConfigMap );
		
		//---------------------- TU ----------------------//
		var ConfigIconUser = {
			position: Glatlon,
			map: GMap,
			title: "eres tu",
			fillOpacity: .9,
			animation: google.maps.Animation.DROP
		};
		
		var IconUser = new google.maps.Marker( ConfigIconUser );
			IconUser.setIcon( "img/icons/car.png" );
			
		// -----------------  locales  ---------------------- //
		
		var GCoder = new google.maps.Geocoder();
		
		var Configlocal = {
			address: "Museo del Oro Cra. 6 #15-88"
		//	address: "catedral de sal de zipaquira, Colombia"
		};
		
		GCoder.geocode( Configlocal, addresslocal );
		
		function addresslocal(dados){
			var Glalo = dados[0].geometry.location;
			
			var ConfigIconlocal = {
				position: Glalo,
				map: GMap,
				title: "Taller Carro"
			};
		    var Iconlocal = new google.maps.Marker( ConfigIconlocal );
			    Iconlocal.setIcon( "img/icons/taller.png" );
		// ---------------------    popup   ------------------------- //
		
			var ConfigPopup = {
				content: '<div id="height:80px; width: 180px"><h2>Taller Repara ya!<h2><br><a href="#">Visitar web</a></div>'
			};
		    var Gpop = new google.maps.InfoWindow( ConfigPopup );
		    
		    google.maps.event.addListener( Iconlocal, "click",function (){
		        Gpop.open( GMap, Iconlocal );
		    });
		}
			
		// ---------------------    Grua   ------------------------- //
		var GCoder1 = new google.maps.Geocoder();
		
		var Configlocal1 = {
			address: "Museo Del Vidrio de Bogotá"
		//	address: "Catedral de Sal, Zipaquirá, Cundimanarca, Colombia"
		};
		
		GCoder1.geocode( Configlocal1, addresslocal1 );
		
		function addresslocal1(dados1){
			var Glalo1 = dados1[0].geometry.location;
			
			var ConfigIconlocal1 = {
				position: Glalo1,
				map: GMap,
				title: "Servicio de Grua"
			};
		    var Iconlocal1 = new google.maps.Marker( ConfigIconlocal1 );
			    Iconlocal1.setIcon( "img/icons/grua.png" );
		}
		
		// ---------------------------------------------------------- //
		
		var ConfigDRender = {
			map: GMap,
			suppressMarkers: true
		};
			
		var ConfigDService = {
			origin: Configlocal1.address,
			destination: Glatlon,
		//	travelMode: google.maps.TravelMode.WALKING
			travelMode: google.maps.TravelMode.DRIVING
		//	travelMode: google.maps.TravelMode.TRANSIT
		//	travelMode: google.maps.TravelMode.BICYCLING
		};
		 
        var directionsDisplay = new google.maps.DirectionsRenderer(ConfigDRender);
        var directionsService = new google.maps.DirectionsService();
		
		    directionsService.route( ConfigDService, FnRutear );
		
		function FnRutear(response, status){
		    //AxB
		    if(status=="OK"){
		        directionsDisplay.setDirections(response);
		    }else{
		        alert( "Error: "+status )
		    }
	    }
		
		// ---------------------------------------------------------- //
			
			
          }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
          });
        } else {
          // Browser doesn't support Geolocation
          handleLocationError(false, infoWindow, map.getCenter());
        }
      }

      function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
                              'Error: The Geolocation service failed.' :
                              'Error: Your browser doesn\'t support geolocation.');
        infoWindow.open(map);
      }
      