	<title>Ashock</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="description" content="By MCDeveloper." />
		<meta name="keywords"  content="key1,key1,key1" />
		<meta name="Resource-type" content="Document" />
		<meta name="author" content="mcdeveloper" />
