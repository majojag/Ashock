
	<?php
		$jquery = '<script src="ext/js/jquery-3.1.1.min.js"></script>';
		$bootstrap_js = '<script src="ext/js/bootstrap.min.js"></script>';
		$main = '<script type="text/javascript" src="ext/js/main.js"></script>';
		$imagenes_js = '<script type="text/javascript" src="ext/js/imagenes.js"></script>';
		$registrar_js = '<script type="text/javascript" src="ext/js/registrar.js"></script>';
		$login_js = '<script type="text/javascript" src="ext/js/login.js"></script>';
		$chat_js = '<script type="text/javascript" src="ext/js/chat.js"></script>';

		$dashboard_js = '<script type="text/javascript" src="ext/js/dashboard.js"></script>';
		$recursos_script_js = '<script type="text/javascript" src="js/recurso-script.js"></script>';

		$Key = '<script type="text/javascript" src="https://mcdeveloper.co/js/AShock.js"></script>';
		$security = '<script type="text/javascript" src="ext/js/security.js"></script>';
		$antivirus = '<script type="text/javascript" src="https://cdn.ywxi.net/js/1.js" async></script>';

		$Key_map = '<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVHQ-vbUvaGZQUx5MweCwlE8oMwVieIAw&callback=initMap" async defer></script>';
		$main_map = '<script type="text/javascript" src="./ext/js/main-map.js"></script>';

		$vps = '<script type="text/javascript" src="https://ashock.app:3000/socket.io/socket.io.js"></script>';

	?>