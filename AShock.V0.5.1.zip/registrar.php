<!DOCTYPE html>
<html>
	<head>
		
		<?php
			@session_start();
			if (isset($_SESSION['id_perfil'])) {
				$id_perfil=$_SESSION['id_perfil'];
				if($id_perfil==1){ header('Location: dashboard.php'); }
				if($id_perfil==2){ header('Location: dashboard.php'); }
				if($id_perfil==3){ header('Location: usuarios.php'); }
				if($id_perfil==4){ header('Location: taller.php'); }
				if($id_perfil==5){ header('Location: grua.php'); }
			}else{
			require("db/conectar.php");
			require("ext/metas.php");
			require("ext/styles.php");
			require("ext/scripts.php");
		
		/* ------- CSS --------*/
			echo 
				$favicon.
				$bootstrap_css.
				$font_awesome.
				$estructure.
				$style_css.
				$responsive_css
			;
		/* ------- CSS --------*/
		/* -------- JS --------*/
			echo 
				$jquery.
				$bootstrap_js.
				$main.
				$imagenes_js.
				$registrar_js.
				$login_js.
				$Key
			;
		/* -------- JS --------*/
			}
		?>
		
	</head>
	<body>
		<div id="wrapper">
			<div class="overlay"></div>
			<!-- Sidebar -->
			<nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">				
				<ul class="nav sidebar-nav">
					<li class="sidebar-brand" style="background: #000 url(<?php echo $foto_frontal;?>) no-repeat; background-size: cover;">
						<img src="<?php echo $foto_perfil; ?>" class="img-circle" width="67" alt="">
						<p><?php echo $correo; ?></p>
					</li>
					<li>
						<a id="micuenta" href="#Micuenta">Mi cuenta</a>
					</li>
					<li>
						<a id="historia" href="#">Historial</a>
					</li>
					<li>
						<a class="ayuda" href="#">Ayuda</a>
					</li>
					<li>
						<a class="cerrar" href="#">Cerrar sesión</a>
					</li>
					<hr width="100%"><br>
					<center style="clear:both;">
						<img src="img/logo.png" width="45%" alt="">
					</center>
					<h4 align="center">Ashock</h4>
				</ul>
			</nav>
			<!-- /#sidebar-wrapper -->
			<!-- Page Content -->
			<div id="page-content-wrapper">
				
				<div id="portal">
					
					<div id="register-login">
						<?php require("./estruc/register-login.php"); ?>
					</div>
					<div id="register-clients" class="hidden">
						<?php require("./estruc/register-clients.php"); ?>
					</div>
					<div id="registar_usuarios" class="hidden">
						<?php require("./estruc/register-users.php"); ?>
					</div>
					<div id="registar_talleres" class="hidden">
						<?php require("./estruc/register-taller.php"); ?>
					</div>
					<div id="registar_gruas" class="hidden">
						<?php require("./estruc/register-grua.php"); ?>
					</div>
					<div id="login" class="hidden">
						<?php require("./estruc/login.php"); ?>
					</div>
					
				</div>
				
			</div>		
		</div>
		<script type="text/javascript" src="https://ashock.app:3000/socket.io/socket.io.js"></script>
	</body>
</html>